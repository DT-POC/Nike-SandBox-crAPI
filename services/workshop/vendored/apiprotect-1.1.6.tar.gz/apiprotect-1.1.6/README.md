# API Protect Python SDK Installation and Usage

## Overview

The Data Theorem API Protect Python SDK is a Python library that provides protection for APIs written in Python. The SDK integrates with your Python API using the API Protect middleware which supports most popular Python frameworks. To Protect an API, all the API developer needs to do is add the API Protect middleware to their web application code set the client Id we provide.

## Installation

### Step 1: Add the package to dependencies

To install API Protect the provided Python package must be added as a dependency, typically by adding it to a requirements.txt file. Here is an example of how to add the package:

#### Example adding dependency to requirements.txt

```
# requirements.txt after adding the apiprotect package
file:./vendored/apiprotect-1.0.1.tar.gz
Jinja2<2.12
SQLAlchemy<1.4.0
advocate>=1.0.0,<2.0
boto3<2.0.0
falcon-cors<1.2.0
falcon<4.0.0
```

#### Example installing dependency via pip

```shell
pip install ./apiprotect-1.0.1.tar.gz
```

### Step 2: Add the middleware to the application

The middleware for your web framework should be imported and added to your application.

**Note: The ordering of middleware is important**

```
This middleware may be added before or after any logging middleware,
but it should be before other middleware or application code.


                                        Request Flow

                                            │
    ┌───────────────────────────────────┐   │
    │        Logging Middleware         │   │
    └───────────────────────────────────┘   │
    ┌───────────────────────────────────┐   │
    │      Api Protect Middleware       │   │
    └───────────────────────────────────┘   │
    ┌───────────────────────────────────┐   │
    │         Other Middleware          │   │
    └───────────────────────────────────┘   │
                                            │
                                            ▼
                     *  OR *

                                       Request Flow

                                            │
    ┌───────────────────────────────────┐   │
    │      Api Protect Middleware       │   │
    └───────────────────────────────────┘   │
    ┌───────────────────────────────────┐   │
    │      Logging Middleware           │   │
    └───────────────────────────────────┘   │
    ┌───────────────────────────────────┐   │
    │         Other Middleware          │   │
    └───────────────────────────────────┘   │
                                            │
                                            ▼

```

#### Example using Falcon middleware

```python
# example using Falcon middleware

from apiprotect.middleware import ApiProtectFalconMiddleware

app = falcon.App(
    middleware=[
        CloudTraceMiddleware(),
        ApiProtectFalconMiddleware(),
        SqlAlchemySessionMiddleware(),
        CORSMiddleware(),
    ]
)

#### Example using WSGI middleware
```python
# example using WSGI middleware

from apiprotect.middleware import ApiProtectWSGIMiddleware

wsgi_app = get_wsgi_application()
protected_wsgi_app = ApiProtectWSGIMiddleware(wsgi_app)
```

### Step 3: Set the Client ID

For each API you protect Data Theorem provides a unique identifier which authenticates the SDK when it communicates with our services. The client id we provide can be set in two way, either via an environment variable DT_API_PROTECT_CLIENT_ID or by passing it directly to the middleware. Setting the environment variable is the preferred method.

**Note: If the client id is present either as the DT_API_PROTECT_CLIENT_ID environment variable, or passed to the middleware, API Protect will activate. If the client_id cannot be easily unset but you do not wish to activate API Protect, you can set DT_API_PROTECT_DEACTIVATE=True to prevent the service from activating.**

If you need to pass the client_id to the middleware without setting an environment variable, here is how to do that:

#### Example passing client_id to Falcon middleware

```python
# example passing client_id to Falcon middleware

import settings  # file-based secure settings management

app = falcon.App(
    middleware=[
        CloudTraceMiddleware(),
        ApiProtectFalconMiddleware(client_id=settings.client_id),
        SqlAlchemySessionMiddleware(),
        CORSMiddleware(),
    ]
)
```

#### Example passing client_id to WSGI middleware

```python
# example passing client_id to WSGI middleware

import settings  # file-based secure settings management

from apiprotect.middleware import ApiProtectWSGIMiddleware

wsgi_app = get_wsgi_application()

protected_wsgi_app = ApiProtectWSGIMiddleware(wsgi_app, client_id=settings.client_id)
```
