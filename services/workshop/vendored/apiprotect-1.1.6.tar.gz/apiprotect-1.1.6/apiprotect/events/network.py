from typing import Tuple
from typing import Union

from pydantic import BaseModel
from typing_extensions import Literal

from apiprotect.events.base import BaseEvent
from apiprotect.requests.models import InboundRequest
from apiprotect.requests.models import InboundRequestResponse
from apiprotect.requests.models import OutboundRequest


class SocketConnectRecord(BaseModel):
    socket_class: str
    address_family: str
    socket_type: str
    addr: Union[
        Tuple[str, int],  # AF_INET -> (address:str, port:int)
        Tuple[str, int, int, int],  # AF_INET6 -> (address:str, port:int, flowinfo:int, scope_id:int)
        str  # AF_UNIX -> str | bytes (converted to str)
        # AF_NETLINK -> (pid:int, groups:int (mask)) (converted to str)
        # AF_TIPC -> (addr_type:int, v1:int, v2:int, v3:int [, scope:int])  (converted to str)
        # AF_QIPCRTR -> (node:int, port:int)  (converted to str)
        # AF_PACKET -> (interface:str, ethernet_proto: int, [int], [int], [int]) (converted to str)
        # ANY OTHER SOCKET FAMILY -> (converted to str)
    ]


class SocketConnectEvent(BaseEvent):
    type: Literal["data_theorem.socket.connect"] = "data_theorem.socket.connect"
    record: SocketConnectRecord


class SocketGetAddrInfoRecord(BaseModel):
    host: str
    port: str
    address_family: str
    socket_type: str
    protocol: str


class SocketGetAddrInfoEvent(BaseEvent):
    type: Literal["data_theorem.socket.getaddrinfo"] = "data_theorem.socket.getaddrinfo"
    record: SocketGetAddrInfoRecord


class InboundHttpRequestEvent(BaseEvent):
    type: Literal["data_theorem.http.inbound_request"] = "data_theorem.http.inbound_request"
    record: InboundRequest


class InboundHttpRequestResponseEvent(BaseEvent):
    type: Literal["data_theorem.http.inbound_request.response"] = "data_theorem.http.inbound_request.response"
    record: InboundRequestResponse


class OutboundHttpRequestEvent(BaseEvent):
    type: Literal["data_theorem.http.outbound_request"] = "data_theorem.http.outbound_request"
    record: OutboundRequest
