from typing import Callable
from typing import Dict
from typing import Union

from apiprotect.events.awslambda import HandlerInvokeEvent
from apiprotect.events.internal import InternalErrorEvent
from apiprotect.events.internal import InternalLogEvent
from apiprotect.events.network import InboundHttpRequestEvent
from apiprotect.events.network import InboundHttpRequestResponseEvent
from apiprotect.events.network import OutboundHttpRequestEvent
from apiprotect.events.network import SocketConnectEvent
from apiprotect.events.network import SocketGetAddrInfoEvent
from apiprotect.events.system import ShutdownEvent

LoggableEventType = Union[
    InboundHttpRequestEvent,
    InboundHttpRequestResponseEvent,
    OutboundHttpRequestEvent,
    SocketConnectEvent,
    SocketGetAddrInfoEvent,
    # generic events
    ShutdownEvent,
    # internal events
    InternalLogEvent,
    InternalErrorEvent,
]

LOGGABLE_EVENT = (
    InboundHttpRequestEvent,
    InboundHttpRequestResponseEvent,
    OutboundHttpRequestEvent,
    SocketConnectEvent,
    SocketGetAddrInfoEvent,
    # generic events
    ShutdownEvent,
    # internal events
    InternalLogEvent,
    InternalErrorEvent,
)

AuditableEventType = Union[InboundHttpRequestEvent, OutboundHttpRequestEvent]
AUDITABLE_EVENT = (InboundHttpRequestEvent, OutboundHttpRequestEvent)


PARSE_MAPPING: Dict[str, Callable] = {
    "data_theorem.handler.invoke": HandlerInvokeEvent.parse_obj,
    "data_theorem.socket.connect": SocketConnectEvent.parse_obj,
    "data_theorem.socket.getaddrinfo": SocketGetAddrInfoEvent.parse_obj,
    "data_theorem.http.outbound_request": OutboundHttpRequestEvent.parse_obj,
}
