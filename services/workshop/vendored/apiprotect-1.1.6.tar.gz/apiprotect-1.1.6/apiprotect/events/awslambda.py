from typing import Any
from typing import Dict
from typing import Optional

from pydantic import BaseModel
from typing_extensions import Literal

from apiprotect.events.base import BaseEvent


class LambdaCognitoIdentity(BaseModel):
    """Information about the Amazon Cognito identity that authorized the request."""

    cognito_identity_id: Optional[str]
    cognito_identity_pool_id: Optional[str]


class LambdaClientContextMobileClient(BaseModel):
    """Mobile Client context that's provided to Lambda by the client application."""

    installation_id: str
    app_title: str
    app_version_name: str
    app_version_code: str
    app_package_name: str


class LambdaClientContext(BaseModel):
    client: Optional[LambdaClientContextMobileClient]
    custom: Dict[str, Any]  # A dict of custom values set by the mobile client application.
    env: Dict[str, Any]  # A dict of environment information provided by the AWS SDK.


class LambdaContext(BaseModel):
    """The LambdaContext static object."""

    function_name: str
    function_version: str
    invoked_function_arn: str
    memory_limit_in_mb: int
    aws_request_id: str
    log_group_name: str
    log_stream_name: str
    identity: Optional[LambdaCognitoIdentity]
    client_context: Optional[LambdaClientContext]


class HandlerInvokeRecord(BaseModel):
    event: Any
    context: LambdaContext


class HandlerInvokeEvent(BaseEvent):
    type: Literal["data_theorem.handler.invoke"] = "data_theorem.handler.invoke"
    record: HandlerInvokeRecord
