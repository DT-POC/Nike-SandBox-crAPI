from typing import Optional
from uuid import uuid4

from typing_extensions import Literal

from apiprotect.events.base import BaseEvent


class AlertEvent(BaseEvent):
    type: Literal["data_theorem.http.alert"] = "data_theorem.http.alert"
    record: Optional[str] = None
    request_id: str = str(uuid4())
