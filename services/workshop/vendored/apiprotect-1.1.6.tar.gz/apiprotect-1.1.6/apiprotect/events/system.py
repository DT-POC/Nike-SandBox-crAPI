import datetime
from typing import Optional

from pydantic import BaseModel
from pydantic import Field
from typing_extensions import Literal


class ShutdownEvent(BaseModel):
    time: str = Field(default_factory=datetime.datetime.utcnow)
    type: Literal["data_theorem.system.shutdown"] = "data_theorem.system.shutdown"
    record: Optional[str] = None
    request_id: str = "system-shutdown"
