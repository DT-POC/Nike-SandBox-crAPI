from datetime import datetime
from typing import Any

from pydantic import BaseModel


class BaseEvent(BaseModel):
    # Should be the time that the event happened, not the the time the instance
    # was instantiated.
    # For example, if an http request happened at a time, then the request's
    # time should be the source of this value. If not available elsewhere, then
    # we can use the time the event was instantiated.
    time: datetime  # iso string or epoch time int, float, or string
    type: str
    record: Any
    # Should come from the InboundRequest. All events that happen should
    # as a result of the initial InboundRequest should have the same request_id.
    request_id: str
