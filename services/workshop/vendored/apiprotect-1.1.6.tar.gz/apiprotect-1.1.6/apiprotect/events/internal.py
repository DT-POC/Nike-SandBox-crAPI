from pydantic import BaseModel
from typing_extensions import Literal

from apiprotect.events.base import BaseEvent


class InternalErrorRecord(BaseModel):
    exception: str
    traceback: str


class InternalErrorEvent(BaseEvent):
    type: Literal["data_theorem.internal.error"] = "data_theorem.internal.error"
    record: InternalErrorRecord


class InternalLogEvent(BaseEvent):
    type: Literal["data_theorem.internal.log"] = "data_theorem.internal.log"
    record: str
