from typing import TYPE_CHECKING
from typing import Any

if TYPE_CHECKING:
    from apiprotect.audit import AuditResult


class InvalidClientIdError(Exception):
    """Client Id is set but invalid."""

    def __init__(self, client_id: Any) -> None:
        super().__init__(f"Client Id '{client_id}' is invalid.")


class PolicyViolationError(Exception):
    """Policy violated by event."""

    def __init__(self, audit_result: "AuditResult") -> None:
        self.audit_result = audit_result
        msg = f"Handling of {self.audit_result.event} result in policy violations: {self.audit_result.result}"
        super().__init__(msg)


class UnprocessableEventError(Exception):
    pass
