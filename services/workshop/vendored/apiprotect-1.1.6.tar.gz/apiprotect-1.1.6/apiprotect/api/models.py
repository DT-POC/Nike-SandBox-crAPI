from typing import Any
from typing import Dict
from typing import List
from typing import Union

from pydantic import BaseModel
from pydantic import validator

from apiprotect.events import AUDITABLE_EVENT
from apiprotect.events import AuditableEventType
from apiprotect.events import LOGGABLE_EVENT
from apiprotect.events import LoggableEventType
from apiprotect.events import PARSE_MAPPING
from apiprotect.events.awslambda import HandlerInvokeEvent
from apiprotect.events.network import InboundHttpRequestEvent
from apiprotect.requests.aws_lambda import from_awslambda_handler_args

LogBatch = List[LoggableEventType]


class LogRequest(BaseModel):
    logs: List[LoggableEventType]

    @validator("logs")
    def validate_logs(cls, logs: LogBatch) -> LogBatch:
        if len(set([event.request_id for event in logs])) > 1:
            raise ValueError(f"logs cannot contain multiple request_ids: {logs}")
        return logs


AuditRequest = AuditableEventType


def parse_event(event: Dict[str, Any]) -> Union[AuditableEventType, LoggableEventType]:
    return PARSE_MAPPING[event["type"]](event)


def parse_auditable_event(event: Dict[str, Any]) -> AuditableEventType:
    parsed_event = parse_event(event)
    if isinstance(parsed_event, HandlerInvokeEvent):
        parsed_event = InboundHttpRequestEvent(
            time=parsed_event.time,
            record=from_awslambda_handler_args(parsed_event.record.event, parsed_event.record.context),
            request_id=parsed_event.request_id,
        )
    if not isinstance(parsed_event, AUDITABLE_EVENT):
        raise TypeError("not an auditable event type: {parsed_event}")
    return parsed_event


def parse_loggable_event(event: Dict[str, Any]) -> LoggableEventType:
    parsed_event = parse_event(event)
    if not isinstance(parsed_event, LOGGABLE_EVENT):
        raise TypeError("not a loggable event type: {parsed_event}")
    return parsed_event
