import json
import logging
from queue import Empty as QueueEmpty
from queue import SimpleQueue
from typing import Optional
from typing import Tuple
from typing import Union
from wsgiref.simple_server import make_server
from wsgiref.simple_server import WSGIServer

import falcon

from apiprotect.api.models import LogRequest
from apiprotect.api.models import parse_auditable_event
from apiprotect.audit import audit_event
from apiprotect.config import ApiProtectConfigurationV2

_logger = logging.getLogger(__name__)


class ApiProtectService:
    def __init__(
        self,
        client_id: str,
        event_queue: SimpleQueue,
        config_queue: SimpleQueue,
        config: Optional[ApiProtectConfigurationV2],
    ) -> None:
        self.client_id = client_id
        self.event_queue = event_queue
        self.config_queue = config_queue

        # use config passed to __init__
        self.config = config or ApiProtectConfigurationV2()

        # try to load a remote config
        try:
            config = self.config_queue.get(timeout=5.0)
        except QueueEmpty:
            # this should not normally happen
            _logger.warning("API Protect could not load a config, using default observability config")

    def on_post_audit(self, req: falcon.Request, resp: falcon.Response) -> None:
        # guard against SSRF
        if req.get_header("Client-Id") != self.client_id:
            resp.status = falcon.HTTP_401
            return

        # default allow
        resp.status = falcon.HTTP_204
        try:
            json_body = json.load(req.bounded_stream)
            _logger.debug(f"audit.on_post json: {json_body}")
            auditable_event = parse_auditable_event(json_body)
            _logger.debug(f"audit.on_post parsed: {type(auditable_event)}")

            # SimpleQueue.get_nowait still acquires semaphore so it is slow
            if getattr(self.config, "needs_refresh", False) and self.config_queue:
                try:
                    new_config = self.config_queue.get_nowait()
                    self.config = new_config
                except QueueEmpty:
                    pass

            audit_result = audit_event(auditable_event, self.config)
            _logger.debug(f"audit.on_post audit_result: {audit_result.result}")
            self.event_queue.put_nowait(audit_result)

            if audit_result.is_block:
                resp.status = falcon.HTTP_200
                resp.text = json.dumps({"request_id": auditable_event.request_id, "blocked": True})

        except Exception as e:
            _logger.debug(f"audit.on_post error: {e}")

    def on_post_log(self, req: falcon.Request, resp: falcon.Response) -> None:
        # guard against SSRF
        if req.get_header("Client-Id") != self.client_id:
            resp.status = falcon.HTTP_401
            return
        try:
            json_body = json.load(req.bounded_stream)
            _logger.debug(f"log.on_post json: {json_body}")
            log_request = LogRequest.parse_obj(json_body)
            _logger.debug(f"log.on_post: parsed:{type(log_request)}")
            if log_request.logs:
                self.event_queue.put_nowait(log_request.logs)
        except Exception as e:
            _logger.debug(f"/log error: {e}")

        resp.status = falcon.HTTP_204

    def on_get_health(self, req: falcon.Request, resp: falcon.Response) -> None:
        resp.status = falcon.HTTP_200


def init_wsgi_app(
    client_id: str, event_queue: SimpleQueue, config_queue: SimpleQueue, config: Optional[ApiProtectConfigurationV2]
) -> Tuple[ApiProtectService, falcon.App]:
    app = falcon.App()
    service = ApiProtectService(client_id, event_queue, config_queue, config)
    app.add_route("/audit", service, suffix="audit")
    app.add_route("/log", service, suffix="log")
    app.add_route("/health", service, suffix="health")
    return service, app


def init_server(host: str, port: Union[int, str], app: falcon.App) -> WSGIServer:
    return make_server(host, int(port), app)


# External extension HTTP API WSGI server
def run_forever(server: WSGIServer) -> None:
    with server as httpd:
        address, port = httpd.server_address[:2]
        _logger.debug(f"serving on http://{address}:{port} ...")
        httpd.serve_forever()
    _logger.debug("stopped")
