from typing import FrozenSet
from typing import Optional
from typing import TYPE_CHECKING

from apiprotect.checks.models import PolicyViolation

if TYPE_CHECKING:
    from apiprotect.requests.models import InboundRequest


def is_user_id_blocked(
    inbound_request: "InboundRequest", blocked_user_ids: FrozenSet[str]
) -> Optional[PolicyViolation]:
    if inbound_request.auth_id in blocked_user_ids:
        return PolicyViolation(type="BLOCKED_USER_ID", context={"user_id": inbound_request.auth_id})
    return None
