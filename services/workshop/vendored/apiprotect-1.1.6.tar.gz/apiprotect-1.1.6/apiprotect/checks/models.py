from dataclasses import dataclass
from dataclasses import field
from enum import Enum
from typing import Any
from typing import Dict
from typing import List
from typing import Optional

from typing_extensions import Literal


class InboundRequestBlockedReasonEnum(str, Enum):
    BLOCKED_DOMAIN = "BLOCKED_DOMAIN"
    BLOCKED_IP_ADDRESS_RANGE = "BLOCKED_IP_ADDRESS_RANGE"
    BLOCKED_USER_AGENT = "BLOCKED_USER_AGENT"
    BLOCKED_USER_ID = "BLOCKED_USER"
    BOLA_ATTACK = "BOLA_ATTACK"
    BOT_DETECTED = "BOT_DETECTED"
    LACK_OF_AUTH = "LACK_OF_AUTH"
    MALICIOUS_DOMAIN = "MALICIOUS_DOMAIN"
    SQLI_ATTACK = "SQLI_ATTACK"
    SSRF_ATTACK = "SSRF_ATTACK"
    XSS_ATTACK = "XSS_ATTACK"
    VOLUMETRIC_ABUSE = "VOLUMETRIC_ABUSE"
    UNKNOWN = "UNKNOWN"


@dataclass
class Attack:
    type: Literal["BOLA_ATTACK", "BOT_DETECTED", "SQLI_ATTACK", "SSRF_ATTACK", "XSS_ATTACK"]
    context: Dict[str, str] = field(default_factory=dict)


@dataclass
class Alert:
    type: Literal["VOLUMETRIC_ABUSE_START", "VOLUMETRIC_ABUSE_STOP"]
    context: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PolicyViolation:
    type: str
    context: Dict[str, str] = field(default_factory=dict)


@dataclass
class Result:
    should_block: bool = False
    reason: Optional[InboundRequestBlockedReasonEnum] = None
    context: Optional[Dict[str, str]] = None
    policy_violations: List[PolicyViolation] = field(default_factory=list)
    attacks: List[Attack] = field(default_factory=list)
    alert: Optional[Alert] = None
