import logging
from ipaddress import IPv4Address
from typing import List
from typing import Optional
from typing import Tuple

import requests

_DT_API_PROTECT_MALICIOUS_IP_LOOKUP_TIMEOUT = 1.0
_DT_API_PROTECT_MALICIOUS_IP_LOOKUP_URL = "http://localhost"
_DT_API_PROTECT_REVERSE_IP_LOOKUP_TIMEOUT = 1.0
_DT_API_PROTECT_REVERSE_IP_LOOKUP_URL = "http://localhost"


_logger = logging.getLogger(__name__)


def is_inbound_ip_malicious(ip_address: Optional[str], dt_client_id: str) -> bool:
    if not ip_address:
        return False
    blocked, reasons = malicious_ip_lookup(ip_address, dt_client_id)
    return blocked


def malicious_ip_lookup(
    ip_address: str, dt_client_id: str, timeout: float = _DT_API_PROTECT_MALICIOUS_IP_LOOKUP_TIMEOUT
) -> Tuple[bool, List[str]]:

    resp = requests.post(
        _DT_API_PROTECT_MALICIOUS_IP_LOOKUP_URL,
        headers={"dt_api_protect_client_id": dt_client_id},
        json={"ip_address": ip_address},
        timeout=timeout,
    )
    resp.raise_for_status()
    resp_json = resp.json()
    return resp_json["blocked"], resp_json["reasons"]


def reverse_ip_lookup(
    ip_address: Optional[IPv4Address], timeout: float = _DT_API_PROTECT_REVERSE_IP_LOOKUP_TIMEOUT
) -> Optional[str]:
    if not ip_address:
        return None
    resp = requests.post(
        _DT_API_PROTECT_REVERSE_IP_LOOKUP_URL, data=f"input={ip_address}".encode("utf-8"), timeout=timeout
    )
    resp.raise_for_status()
    resp_json = resp.json()

    if "top_domain" not in resp_json:
        raise ValueError("ip address does not resolve to a domain")
    return resp_json["top_domain"]
