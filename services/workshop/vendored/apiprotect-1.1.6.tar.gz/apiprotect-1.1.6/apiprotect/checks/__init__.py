import logging
from typing import TYPE_CHECKING

from apiprotect.checks.authentication import is_user_id_blocked
from apiprotect.checks.authorization import is_inbound_ip_address_blocked
from apiprotect.checks.authorization import is_inbound_ip_domain_blocked
from apiprotect.checks.authorization import is_user_agent_blocked
from apiprotect.checks.injection import is_sqli_attack
from apiprotect.checks.models import InboundRequestBlockedReasonEnum
from apiprotect.checks.models import Result
from apiprotect.checks.ssrf import is_ssrf_attack
from apiprotect.requests import InboundRequest
from apiprotect.requests import OutboundRequest

if TYPE_CHECKING:
    from apiprotect.config.models import ApiProtectConfigurationV2

_logger = logging.getLogger(__name__)


def should_block_inbound_request(
    inbound_request: InboundRequest, config: "ApiProtectConfigurationV2", fail_fast: bool = True
) -> Result:
    """Check inbound request to determine if an event is allowed based on current config.

    Perform attack checks first, then perform policy checks.
    """
    # default allow
    result = Result(should_block=False)

    # Begin Attack Detection
    try:
        attack = is_ssrf_attack(
            inbound_request,
            allowed_ips=config.attack_prevention_configuration.ssrf_allowed_ip_ranges,
        )
        if attack:
            result.attacks.extend(attack)
            if config.attack_prevention_configuration.block_ssrf_attacks:
                # block
                result.should_block = True
                result.reason = InboundRequestBlockedReasonEnum.SSRF_ATTACK
            if fail_fast:
                return result
    except Exception:
        _logger.exception("Error checking is_ssrf_attack")

    try:
        attacks = is_sqli_attack(inbound_request, fail_fast=fail_fast)
        if attacks:
            result.attacks.extend(attacks)
            if config.attack_prevention_configuration.block_sqli_attacks:
                # block
                result.should_block = True
                result.reason = InboundRequestBlockedReasonEnum.SQLI_ATTACK
            if fail_fast:
                return result
    except Exception:
        _logger.exception("Error checking is_sqli_attack")

    """
    # TODO: johng reduce xss false positives in user-agent string and enable
    try:
        attacks = is_xss_attack(inbound_request, fail_fast=fail_fast)
        if attacks:
            result.attacks.extend(attacks)
            if config.attack_prevention_configuration.block_xss_attacks:
                # block
                result.should_block = True
                result.reason = InboundRequestBlockedReasonEnum.XSS_ATTACK
            if fail_fast:
                return result
    except Exception:
        _logger.exception("Error checking is_xss_attack")
    """

    # Begin Policy Violation Checks
    if config.authentication_configuration.blocked_user_ids:
        try:
            violation = is_user_id_blocked(inbound_request, config.authentication_configuration.blocked_user_ids)
            if violation:
                result.policy_violations.append(violation)
                result.should_block = True
                result.reason = InboundRequestBlockedReasonEnum.BLOCKED_USER_ID
            if fail_fast:
                return result

        except Exception:
            _logger.exception("Error checking is_user_id_blocked")

    if config.authorization_configuration.blocked_ip_address_ranges:

        try:
            violation = is_inbound_ip_address_blocked(
                inbound_request, config.authorization_configuration.blocked_ip_address_ranges
            )
            if violation:
                result.policy_violations.append(violation)
                result.should_block = True
                result.reason = InboundRequestBlockedReasonEnum.BLOCKED_IP_ADDRESS_RANGE
            if fail_fast:
                return result
        except Exception:
            _logger.exception("Error checking is_inbound_ip_address_blocked")

    if config.authorization_configuration.blocked_user_agents:
        try:
            violation = is_user_agent_blocked(inbound_request, config.authorization_configuration.blocked_user_agents)
            if violation:
                result.policy_violations.append(violation)
                result.should_block = True
                result.reason = InboundRequestBlockedReasonEnum.BLOCKED_USER_AGENT
            if fail_fast:
                return result
        except Exception:
            _logger.exception("Error checking is_user_agent_blocked")

    if config.authorization_configuration.blocked_domains:
        try:
            violation = is_inbound_ip_domain_blocked(
                inbound_request, config.authorization_configuration.blocked_domains
            )
            if violation:
                result.policy_violations.append(violation)
                result.should_block = True
                result.reason = InboundRequestBlockedReasonEnum.BLOCKED_DOMAIN
            if fail_fast:
                return result
        except Exception:
            _logger.exception("Error checking is_ip_domain_blocked")

    return result


def should_block_outbound_request(
    outbound_request: OutboundRequest, config: "ApiProtectConfigurationV2", fail_fast: bool = True
) -> Result:

    return Result(should_block=False)
