from ipaddress import IPv4Address
from ipaddress import IPv4Network
from typing import FrozenSet
from typing import Optional
from typing import TYPE_CHECKING

from apiprotect.checks.models import PolicyViolation
from apiprotect.checks.net import reverse_ip_lookup

if TYPE_CHECKING:
    from apiprotect.requests.models import InboundRequest


def is_inbound_ip_address_blocked(
    inbound_request: "InboundRequest", blocked_ip_address_ranges: FrozenSet[IPv4Network]
) -> Optional[PolicyViolation]:
    if not inbound_request.source_ip_address:
        return None

    # use network instead of address because source_ip_address may use cidr notation
    source_ip_addr = IPv4Network(inbound_request.source_ip_address)

    for net in blocked_ip_address_ranges:
        if source_ip_addr == net or source_ip_addr in net:
            return PolicyViolation(type="BLOCKED_IP_ADDRESS_RANGE", context={"ip_address": str(source_ip_addr)})

    return None


def is_user_agent_blocked(
    inbound_request: "InboundRequest", blocked_user_agents: FrozenSet[str]
) -> Optional[PolicyViolation]:
    if inbound_request.user_agent in blocked_user_agents:
        return PolicyViolation(type="BLOCKED_USER_AGENT", context={"user_agent": inbound_request.user_agent})
    return None


def is_inbound_ip_domain_blocked(
    inbound_request: "InboundRequest", blocked_domains: FrozenSet[str]
) -> Optional[PolicyViolation]:
    if not inbound_request.source_ip_address:
        return None

    reverse_lookup_hostname = reverse_ip_lookup(IPv4Address(inbound_request.source_ip_address))
    if reverse_lookup_hostname and reverse_lookup_hostname in blocked_domains:
        return PolicyViolation(type="BLOCKED_DOMAIN", context={"domain": reverse_lookup_hostname})

    return None
