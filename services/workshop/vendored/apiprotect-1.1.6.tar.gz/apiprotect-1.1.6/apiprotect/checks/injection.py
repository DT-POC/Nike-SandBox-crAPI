import decimal
from functools import singledispatch
from typing import Any
from typing import Dict
from typing import List
from typing import NamedTuple
from typing import Optional
from typing import Tuple
from typing import TYPE_CHECKING
from typing import Union

import libinjection

from apiprotect.checks.models import Attack
from apiprotect.requests.models import RequestLocationEnum

if TYPE_CHECKING:
    from apiprotect.requests import InboundRequest

# AWS adds Decimal type to Python JSON types
JSON_TYPES = Union[dict, list, int, float, bool, str, None, decimal.Decimal]


class LibInjectAttackType(NamedTuple):
    method_name: str
    result_key: str


SQLI_CHECK = LibInjectAttackType(method_name="is_sql_injection", result_key="is_sqli")
XSS_CHECK = LibInjectAttackType(method_name="is_xss", result_key="is_xss")


@singledispatch
def _type_contains_attack(item: Any, libinject_attack_type: LibInjectAttackType) -> Tuple[bool, Any]:
    raise ValueError(f"Unsupported libinjection check type {type(item)}")


@_type_contains_attack.register(dict)
def _dict_contains_attack(items: Dict, libinject_attack_type: LibInjectAttackType) -> Tuple[bool, Any]:
    for k, v in items.items():
        is_attack, _ = _type_contains_attack(v, libinject_attack_type)
        if is_attack:
            return True, v
        is_attack, _ = _type_contains_attack(k, libinject_attack_type)
        if is_attack:
            return True, k
    return False, None


@_type_contains_attack.register(list)
def _list_contains_attack(items: List, libinject_attack_type: LibInjectAttackType) -> Tuple[bool, Any]:
    is_attack = False
    for item in items:
        is_attack, attack = _type_contains_attack(item, libinject_attack_type)
        if is_attack:
            return (is_attack, attack)
    return False, None


@_type_contains_attack.register(bytes)
@_type_contains_attack.register(str)
def _string_contains_attack(str_item: str, libinject_attack_type: LibInjectAttackType) -> Tuple[bool, Any]:
    # load the function (either `is_sql_injection` or `is_xss`) from the libinjection module
    libinjection_function = getattr(libinjection, libinject_attack_type.method_name)
    libinjection_result = libinjection_function(str_item)
    if libinjection_result[libinject_attack_type.result_key]:
        return True, str_item
    return False, None


@_type_contains_attack.register(type(None))
@_type_contains_attack.register(int)
@_type_contains_attack.register(float)
@_type_contains_attack.register(bool)
@_type_contains_attack.register(decimal.Decimal)  # AWS does this
def _ignored_type_contains_attack(
    item: Union[int, float, decimal.Decimal, None], libinject_attack_type: LibInjectAttackType
) -> Tuple[bool, Any]:
    """Return `False` because these types cannot contain an sqli or xss attack."""
    return False, None


def is_sqli_attack(inbound_request: "InboundRequest", fail_fast: bool = True) -> Optional[List[Attack]]:
    attacks = []
    if inbound_request.query is not None:
        is_attack, payload = _type_contains_attack(inbound_request.query, SQLI_CHECK)
        if is_attack:
            attacks.append(
                Attack(
                    type="SQLI_ATTACK", context={"payload": payload, "location": RequestLocationEnum.QUERY_STRING.value}
                )
            )
            if fail_fast:
                return attacks
    body = inbound_request.parsed_body if inbound_request.parsed_body is not None else inbound_request.body
    if body:
        is_attack, payload = _type_contains_attack(body, SQLI_CHECK)
        if is_attack:
            attacks.append(
                Attack(type="SQLI_ATTACK", context={"payload": payload, "location": RequestLocationEnum.BODY.value})
            )
            if fail_fast:
                return attacks
    if inbound_request.headers is not None:
        is_attack, payload = _type_contains_attack(inbound_request.headers, SQLI_CHECK)
        if is_attack:
            attacks.append(
                Attack(type="SQLI_ATTACK", context={"payload": payload, "location": RequestLocationEnum.HEADERS.value})
            )
            if fail_fast:
                return attacks
    if not attacks:
        return None
    return attacks


def is_xss_attack(inbound_request: "InboundRequest", fail_fast: bool = True) -> Optional[List[Attack]]:
    attacks = []
    if inbound_request.query is not None:
        is_attack, payload = _type_contains_attack(inbound_request.query, XSS_CHECK)
        if is_attack:
            attacks.append(
                Attack(
                    type="XSS_ATTACK", context={"payload": payload, "location": RequestLocationEnum.QUERY_STRING.value}
                )
            )
            if fail_fast:
                return attacks
    body = inbound_request.parsed_body if inbound_request.parsed_body is not None else inbound_request.body
    if body:
        is_attack, payload = _type_contains_attack(body, XSS_CHECK)
        if is_attack:
            attacks.append(
                Attack(type="XSS_ATTACK", context={"payload": payload, "location": RequestLocationEnum.BODY.value})
            )
            if fail_fast:
                return attacks

    if inbound_request.headers is not None:
        is_attack, payload = _type_contains_attack(inbound_request.headers, XSS_CHECK)
        if is_attack:
            attacks.append(
                Attack(type="XSS_ATTACK", context={"payload": payload, "location": RequestLocationEnum.HEADERS.value})
            )
            if fail_fast:
                return attacks
    if not attacks:
        return None
    return attacks
