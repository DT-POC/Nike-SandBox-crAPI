import enum
import ipaddress
import logging
import re
import socket
from functools import lru_cache
from ipaddress import IPv4Address
from ipaddress import IPv4Network
from ipaddress import IPv6Address
from ipaddress import IPv6Network
from typing import Any
from typing import FrozenSet
from typing import List
from typing import Optional
from typing import Tuple
from typing import Union
from urllib.parse import urlparse

from advocate import AddrValidator

from apiprotect.checks.models import Attack
from apiprotect.requests.models import InboundRequest
from apiprotect.requests.models import RequestLocationEnum
from apiprotect.utils import objwalk

IPNetwork = Union[IPv4Network, IPv6Network]
IPAddress = Union[IPv4Address, IPv6Address]

_logger = logging.getLogger(__name__)

STRING_TYPES = (str, bytes)

POSSIBLE_IP_ADDRESS_PATTERN = re.compile(r"^[0-9a-fx\.:\[\]]+$", re.IGNORECASE)


class HostTypeEnum(str, enum.Enum):
    IP_ADDRESS = "IP_ADDRESS"
    HOSTNAME = "HOSTNAME"


# Digital Ocean uses http://metadata
DEFAULT_BLOCKED_INBOUND_REQUEST_HOSTNAMES = frozenset(
    ("localhost", "metadata.google.internal", "metadata", "metadata.packet.net")
)

# Oracle cloud uses http:/192.0.0.192 for metadata
DEFAULT_BLOCKED_INBOUND_REQUEST_IPS = frozenset((ipaddress.ip_network("192.0.0.192/32"),))  # Oracle Cloud metadata


@lru_cache(maxsize=5)
def _get_address_validator(
    blocked_ips: Optional[FrozenSet[IPNetwork]] = None,
    allowed_ips: Optional[FrozenSet[IPNetwork]] = None,
    allowed_ports: Optional[FrozenSet[int]] = None,
    blocked_ports: Optional[FrozenSet[int]] = None,
    blocked_hostnames: Optional[FrozenSet[str]] = None,
    allow_ipv6: bool = False,
    allow_teredo: bool = False,
    allow_6to4: bool = False,
    allow_dns64: bool = False,
) -> AddrValidator:
    # if allowed_ports and blocked_ports are None, then
    # AddrValidator sets allowed_ports to:  {80, 8080, 443, 8443, 8000}
    return AddrValidator(
        ip_blacklist=blocked_ips,
        ip_whitelist=allowed_ips,
        port_whitelist=allowed_ports,
        port_blacklist=blocked_ports,
        hostname_blacklist=blocked_hostnames,
        allow_ipv6=allow_ipv6,
        allow_teredo=allow_teredo,
        allow_6to4=allow_6to4,
        allow_dns64=allow_dns64,
    )


def _get_inbound_request_address_validator(
    blocked_ips: Optional[FrozenSet[IPNetwork]] = None,
    allowed_ips: Optional[FrozenSet[IPNetwork]] = None,
    allowed_ports: Optional[FrozenSet[int]] = None,
    blocked_ports: Optional[FrozenSet[int]] = None,
    blocked_hostnames: Optional[FrozenSet[str]] = None,
    allow_ipv6: bool = False,
    allow_teredo: bool = False,
    allow_6to4: bool = False,
    allow_dns64: bool = False,
) -> AddrValidator:

    if blocked_ips is None:
        blocked_ips = DEFAULT_BLOCKED_INBOUND_REQUEST_IPS
    if blocked_hostnames is None:
        blocked_hostnames = DEFAULT_BLOCKED_INBOUND_REQUEST_HOSTNAMES

    return _get_address_validator(
        blocked_ips=blocked_ips,
        allowed_ips=allowed_ips,
        allowed_ports=allowed_ports,
        blocked_ports=blocked_ports,
        blocked_hostnames=blocked_hostnames,
        allow_ipv6=allow_ipv6,
        allow_teredo=allow_teredo,
        allow_6to4=allow_6to4,
        allow_dns64=allow_dns64,
    )


def _parse_host(host: Any) -> Tuple[HostTypeEnum, Union[IPAddress, str]]:
    # use regex to avoid calling getaddrinfo for non-ipaddress
    match = POSSIBLE_IP_ADDRESS_PATTERN.search(host)
    if match:
        try:
            # socket.AI_NUMERICHOST flag means no network lookups
            _, _, _, _, sockaddr = socket.getaddrinfo(host, None, type=socket.SOCK_DGRAM, flags=socket.AI_NUMERICHOST)[
                0
            ]
            return HostTypeEnum.IP_ADDRESS, ipaddress.ip_address(sockaddr[0])
        except socket.gaierror:
            # raised by socket.gethostbyname
            # some addresses will return an error from socket.gethostbyname
            # but be parsed by ipaddress.ip_address, eg: '::', '0000::1', '0:0:0:0:0:ffff:127.0.0.1'
            try:
                return HostTypeEnum.IP_ADDRESS, ipaddress.ip_address(host)
            except ValueError:
                return HostTypeEnum.HOSTNAME, host
        except ValueError:
            # raised when ipaddress.ip_address fails to parse
            pass
        except Exception as e:
            _logger.debug(f"Error parsing {host}: {e}. Ignoring...")
    return HostTypeEnum.HOSTNAME, host


def ip_address_is_ssrf(address: IPAddress, validator: AddrValidator) -> bool:
    if not address:
        return False
    return not validator.is_ip_allowed(address)


def hostname_is_ssrf(hostname: str, validator: AddrValidator) -> bool:
    return not validator.is_hostname_allowed(hostname)


def _contains_attack(item: Union[str, bytes], validator: AddrValidator) -> Tuple[bool, Any]:
    if isinstance(item, bytes):
        item = item.decode()
    parsed_url = urlparse(item)

    if not all([parsed_url.scheme, parsed_url.netloc, parsed_url.hostname]):
        # value is not a url
        return False, None

    host_type, parsed_host = _parse_host(parsed_url.hostname)

    if host_type == HostTypeEnum.IP_ADDRESS:
        ssrf_result = ip_address_is_ssrf(parsed_host, validator)  # type: ignore
    else:
        ssrf_result = hostname_is_ssrf(parsed_host, validator)  # type: ignore
    if ssrf_result:
        return True, item
    return False, None


def is_ssrf_attack(
    inbound_request: InboundRequest,
    blocked_ips: Optional[FrozenSet[IPNetwork]] = None,
    allowed_ips: Optional[FrozenSet[IPNetwork]] = None,
    allowed_ports: Optional[FrozenSet[int]] = None,
    blocked_ports: Optional[FrozenSet[int]] = None,
    blocked_hostnames: Optional[FrozenSet[str]] = None,
    allow_ipv6: bool = False,
    allow_teredo: bool = False,
    allow_6to4: bool = False,
    allow_dns64: bool = False,
    fail_fast: bool = True,
) -> Optional[List[Attack]]:

    attacks = []

    validator = None

    if inbound_request.query is not None:

        validator = _get_inbound_request_address_validator(
            blocked_ips=blocked_ips,
            allowed_ips=allowed_ips,
            allowed_ports=allowed_ports,
            blocked_ports=blocked_ports,
            blocked_hostnames=blocked_hostnames,
            allow_ipv6=allow_ipv6,
            allow_teredo=allow_teredo,
            allow_6to4=allow_6to4,
            allow_dns64=allow_dns64,
        )
        for obj_type, obj_path, obj in objwalk(inbound_request.query):
            if obj_type not in STRING_TYPES:
                continue
            is_attack, payload = _contains_attack(obj, validator)
            if is_attack:
                attacks.append(
                    Attack(
                        type="SSRF_ATTACK",
                        context={
                            "payload": payload,
                            "location": RequestLocationEnum.QUERY_STRING.value,
                            "path": ".".join(str(p) for p in obj_path),
                        },
                    )
                )
                if fail_fast:
                    return attacks

    body = inbound_request.parsed_body if inbound_request.parsed_body is not None else inbound_request.body
    if body:
        validator = validator or _get_inbound_request_address_validator(
            blocked_ips=blocked_ips,
            allowed_ips=allowed_ips,
            allowed_ports=allowed_ports,
            blocked_ports=blocked_ports,
            blocked_hostnames=blocked_hostnames,
            allow_ipv6=allow_ipv6,
            allow_teredo=allow_teredo,
            allow_6to4=allow_6to4,
            allow_dns64=allow_dns64,
        )

        for obj_type, obj_path, obj in objwalk(body):
            if obj_type not in STRING_TYPES:
                continue
            is_attack, payload = _contains_attack(obj, validator)
            if is_attack:
                attacks.append(
                    Attack(
                        type="SSRF_ATTACK",
                        context={
                            "payload": payload,
                            "location": RequestLocationEnum.BODY.value,
                            "path": ".".join(str(p) for p in obj_path),
                        },
                    )
                )
                if fail_fast:
                    return attacks
    return attacks or None
