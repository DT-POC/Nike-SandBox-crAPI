import ipaddress

# --- SSRF related ---
# first line of defense against malicious domains, for example this will guard against adding the metadata service
# domain (metadata.google.internal) and the loopback address (localhost)
_BLOCKED_TLDS = ("localhost", "internal", "home", "mail", "corp", "example", "test", "invalid")

# second line of defense against malicious domains
# we need this to guard against domains that slip pass the first line of defense. An attacker can easily register a
# domain that can resolve to the underlying loopback or gcp metadata service link-local IP address. So we must check
# the actual IP address that a hostname resolves to and determine if it is restricted or reserved
# see https://en.wikipedia.org/wiki/Reserved_IP_addresses for a current list of reserved or restricted IP addresses
_BLOCKED_IPV4_BLOCKS = (
    ipaddress.IPv4Network("0.0.0.0/8"),  # Current network (only valid as source address).
    ipaddress.IPv4Network("10.0.0.0/8"),  # Used for local communications within a private network
    ipaddress.IPv4Network("100.64.0.0/10"),  # Shared address space
    ipaddress.IPv4Network("127.0.0.0/8"),  # Used for loopback addresses to the local hos
    ipaddress.IPv4Network("169.254.0.0/16"),  # Used for link-local addresses
    ipaddress.IPv4Network("172.16.0.0/12"),  # Used for local communications within a private network
    ipaddress.IPv4Network("192.0.0.0/24"),  # IETF Protocol Assignments
    ipaddress.IPv4Network("192.0.2.0/24"),  # Assigned as TEST-NET-1, documentation and examples
    ipaddress.IPv4Network("192.88.99.0/24"),  # Formerly used for IPv6 to IPv4 relay
    ipaddress.IPv4Network("192.168.0.0/16"),  # Used for local communications within a private network
    ipaddress.IPv4Network("198.18.0.0/15"),  # Used for benchmark testing of inter-network communications
    ipaddress.IPv4Network("198.51.100.0/24"),  # Assigned as TEST-NET-2, documentation and examples
    ipaddress.IPv4Network("203.0.113.0/24"),  # Assigned as TEST-NET-3, documentation and examples
    ipaddress.IPv4Network("224.0.0.0/4"),  # In use for IP multicast
    ipaddress.IPv4Network("240.0.0.0/4"),  # Reserved for future use
    ipaddress.IPv4Network("255.255.255.255/32"),  # Reserved for the "limited broadcast" destination address
)

_BLOCKED_IPV6_BLOCKS = (
    # ipaddress.IPv6Network("::/0"),  # although this is reserved, this includes every IP Address
    ipaddress.IPv6Network("::/128"),  # unspecified address
    ipaddress.IPv6Network("::1/128"),  # loopback address
    # ipaddress.IPv6Network("::ffff:0:0/96"),  # these are IPv4 mapped addresses, allowable
    # ipaddress.IPv6Network("::ffff:0:0:0/96"),  # these are IPv4 translated addresses, allowable
    # ipaddress.IPv6Network("64:ff9b::/96"),  # these are also IPv4 translated addresses, allowable
    ipaddress.IPv6Network("100::/64"),  # this is the blackhole address for IPv6
    # ipaddress.IPv6Network("2001::/32"),  # Teredo tunneling, should be allowable
    ipaddress.IPv6Network("2001:20::/28"),  # ORCHID ip addresses, these are non-routable
    ipaddress.IPv6Network("2001:db8::/32"),  # Addresses used in documentation and example source code
    # ipaddress.IPv6Network("2002::/16"),  # The 6to4 addressing scheme (now deprecated), allowable
    ipaddress.IPv6Network("fc00::/7"),  # Unique Local addresses
    ipaddress.IPv6Network("fe80::/10"),  # Link Local addresses
    ipaddress.IPv6Network("ff00::/8"),  # Global multicast address block
)

_COMBINED_IPV4_IPV6 = _BLOCKED_IPV4_BLOCKS + _BLOCKED_IPV6_BLOCKS
