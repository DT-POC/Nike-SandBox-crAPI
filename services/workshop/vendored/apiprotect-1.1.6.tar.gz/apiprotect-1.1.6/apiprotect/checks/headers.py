from typing import Dict
from typing import Optional

from apiprotect.utils import case_insensitive_mapping_lookup


def match_header_key_value(headers: Optional[Dict[str, str]], key: str, value: str) -> bool:
    return headers is not None and value == case_insensitive_mapping_lookup(headers, key, default=None)
