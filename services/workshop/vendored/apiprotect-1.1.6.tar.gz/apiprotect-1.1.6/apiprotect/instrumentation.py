import datetime
import functools
import importlib
import logging
import socket
import sys
import traceback
from typing import TYPE_CHECKING
from typing import Any
from typing import Mapping
from typing import Optional

from pydantic import ValidationError

from apiprotect.audit import audit_event
from apiprotect.events import InternalErrorEvent
from apiprotect.events import OutboundHttpRequestEvent
from apiprotect.events import SocketConnectEvent
from apiprotect.events import SocketGetAddrInfoEvent
from apiprotect.exceptions import PolicyViolationError
from apiprotect.middleware.local_context import ctx
from apiprotect.requests.models import OutboundRequest
from apiprotect.utils import log_and_suppress
from apiprotect.events.internal import InternalErrorRecord
from apiprotect.events.network import SocketConnectRecord, SocketGetAddrInfoRecord

if TYPE_CHECKING:
    from apiprotect.config.models import ApiProtectConfigurationV2

_logger = logging.getLogger(__name__)

# import and instrument http client lib to audit outbound requests
HTTP_CLIENT_MODULE = importlib.import_module("http.client")
HTTP_CLIENT_CONNECTION_CLASS = getattr(HTTP_CLIENT_MODULE, "HTTPConnection")


class AuditHookRegistrationError(Exception):
    """Raised when we try register our audit hook twice."""


def instrument_http_client_connection(http_client_connection_class: Any = HTTP_CLIENT_CONNECTION_CLASS) -> None:
    """Instruments `http.client.HTTPConnection.request` and `http.client.HTTPSConnection.request`"""

    def patched_request(
        conn_instance: Any,
        method: str,
        url: str,
        body: Optional[Any] = None,
        headers: Optional[Mapping] = {},
        *,
        encode_chunked: Optional[bool] = False,
    ) -> Any:
        """
        Instruments stdlib's http.client.HTTPConnection.request method

        This will instrument most ways python makes http requests including:
            - http.client from stdlib
            - urllib from stdlib (via http.client)
            - urllib3 (via http.client)
            - requests (via urllib3)
            - boto (via requests)
            - advocate (via requests)

        """
        # we may block the outgoing request by raising an exception in the call to sys.audit below
        try:
            sys.audit("http.client.HttpConnection.request", conn_instance, method, url, body, headers)
        except PolicyViolationError as e:
            raise e

        return conn_instance._send_request(method, url, body, headers, encode_chunked)

    if getattr(http_client_connection_class, "request") is patched_request:
        return
    setattr(http_client_connection_class, "request", patched_request)


def register_sys_audit_hook(config: "ApiProtectConfigurationV2") -> None:
    """Register our sys.audit hook handler.

    We must only register our audit hook handler once to avoid duplicate events.
    Additional calls to this function should have no effect.
    """

    try:
        # Send this event before registering our audit hook handler to detect if
        # it is already registered.
        #
        # If our handler is not registered, the audit event is ignored and we
        # register our handler in the else block
        #
        # If our handler is registered, it raises DataTheoremAuditHookRegistrationError
        #  which we ignore and we know our handler is registered.
        sys.audit("dt_api_protect.register_sys_audit_hook")
    except AuditHookRegistrationError:
        pass
    else:
        audit_hook_func = functools.partial(sys_audit_hook, config)
        sys.addaudithook(audit_hook_func)


def _handle_socket_connect_event(request_id: str, args: Any) -> None:
    """Handle `socket.connect` sys.audit event."""
    _logger.debug(f"handling socket.connect event request_id:{request_id} args: {args!r}")
    socket_instance, addr = args
    """
    Addresses can be either tuples of varying lengths:
        socket_instance.family == AF_INET -> addr (address:str, port:int)
        socket_instance.family == AF_INET6 -> addr: (address:str, port:int, flowinfo:int, scope_id:int)
        socket_instance.family == AF_UNIX -> addr: str | bytes
        socket_instance.family == AF_UNSPEC -> addr: Any
        socket_instance.family == AF_NETLINK -> addr: (pid:int, groups:int (mask))
        socket_instance.family == AF_TIPC -> addr: (addr_type:int, v1:int, v2:int, v3:int [, scope])
        socket_instance.family == AF_QIPCRTR -> addr: (node:int, port:int)
        socket_instance.family == AF_PACKET -> addr: (interface:str, ethernet_proto: int, [int], [int], [int])
    addr: Union[tuple[Any, ...], str, bytes]
    """

    if socket_instance.family in {socket.AF_INET, socket.AF_INET6}:
        # addr is (address, port) or (address, port, flowinfo, scope_id)
        pass
    elif socket_instance.family == socket.AF_UNIX and isinstance(addr, bytes):
        addr = addr.decode("utf-8")
    else:
        # default is to seriaize as string
        addr = str(addr)

    record = {
        "socket_class": socket_instance.__class__.__qualname__,
        "address_family": socket.AddressFamily(socket_instance.family).name,
        "socket_type": socket.SocketKind(socket_instance.type).name,
        "addr": addr,
    }

    socket_connect_event = SocketConnectEvent(
        request_id=request_id, record=SocketConnectRecord(**record), time=datetime.datetime.utcnow()
    )
    ctx.put_event(socket_connect_event)


def _handle_socket_getaddrinfo_event(request_id: str, args: Any) -> None:
    """Handle `socket.getaddrinfo` sys.audit event."""
    _logger.debug(f"handling socket.getaddrinfo event request_id:{request_id} args: {args!r}")
    host, port, address_family, socket_type, protocol = args

    """
    host: bytearray | bytes | str | None,
    port: str | int | None,
    family: int = ...,
    type: int = ...,
    proto: int = ...,
    """

    if isinstance(host, (bytes, bytearray)):
        try:
            host = host.decode("utf-8")
        except Exception:
            host = str(host)

    record = {
        "host": host,
        "port": port,
        "address_family": socket.AddressFamily(address_family).name,
        "socket_type": socket.SocketKind(socket_type).name,
        "protocol": protocol,
    }

    socket_get_addr_info_event = SocketGetAddrInfoEvent(
        request_id=request_id, record=SocketGetAddrInfoRecord(**record), time=datetime.datetime.utcnow()
    )
    ctx.put_event(socket_get_addr_info_event)


def _handle_http_request_event(request_id: str, config: "ApiProtectConfigurationV2", args: Any) -> None:
    """Handle `http.client.HttpConnection.request` sys.audit event."""
    _logger.debug(f"handling http.client.HttpConnection.request event request_id:{request_id} " f"args: {args!r}")
    # http.client.HTTP[S]Conection, method, url, body, headers
    conn_instance, method, url, _body, headers = args

    try:
        # convert MultiValueDict like objects
        headers = dict(headers)
    except Exception as e:
        headers = {"data_theorem_headers_serialization_error": str(e)}
    record = {
        "scheme": "https" if conn_instance.__class__.__name__.startswith("HTTPS") else "http",
        "host": conn_instance.host,
        "port": conn_instance.port,
        "method": method,
        "url": url,
        "body": "",
        "headers": headers,
    }

    outbound_request_event = OutboundHttpRequestEvent(
        request_id=request_id, record=OutboundRequest(**record), time=datetime.datetime.utcnow()
    )
    audit_result = audit_event(outbound_request_event, config)
    ctx.put_event(audit_result)

    audit_result.raise_if_block()


EVENT_HANDLER_MAP = {
    "dt_api_protect.register_sys_audit_hook": None,
    "socket.connect": _handle_socket_connect_event,
    "socket.getaddrinfo": _handle_socket_getaddrinfo_event,
    "http.client.HttpConnection.request": _handle_http_request_event,
}


def sys_audit_hook(config: "ApiProtectConfigurationV2", event: str, args: Any) -> None:
    if event not in EVENT_HANDLER_MAP:
        return
    if event == "dt_api_protect.register_sys_audit_hook":
        # avoid registering our audit hook multiple times
        raise AuditHookRegistrationError("Audit hook already registered")

    request_id = ctx.request_id
    if not request_id:
        _logger.debug(f"ignored {event} {args!r} because request_id is not set")
        return

    handler_func = EVENT_HANDLER_MAP[event]
    try:
        if event == "http.client.HttpConnection.request":
            handler_func(request_id, config, args)  # type: ignore
        else:
            handler_func(request_id, args)  # type: ignore
    except AuditHookRegistrationError as e:
        _logger.debug("raising AuditHookRegistrationError")
        raise e
    except PolicyViolationError as e:
        # raise this to block the event
        _logger.debug(f"raising PolicyViolationError for {event} {args!r}: {e}")
        raise e
    except ValidationError as e:
        _logger.debug(f"ValidationError while handling event {event}: {e}", exc_info=True)
        with log_and_suppress(logger=_logger):
            ctx.put_event(
                InternalErrorEvent(
                    request_id=request_id,
                    record=InternalErrorRecord(exception=str(e), traceback=traceback.format_exc()),
                    time=datetime.datetime.utcnow(),
                )
            )
    except Exception as e:
        _logger.debug(f"Error in handling audit_hook for {event} {args!r}: {e}", exc_info=True)
        with log_and_suppress(logger=_logger):
            ctx.put_event(
                InternalErrorEvent(
                    request_id=request_id,
                    record=InternalErrorRecord(exception=str(e), traceback=traceback.format_exc()),
                    time=datetime.datetime.utcnow(),
                )
            )
