import io
import logging  # nosemgrep: no_import_logging

_log_stream = io.StringIO()
_handler = logging.StreamHandler(stream=_log_stream)
_handler.setFormatter(logging.Formatter(fmt="[%(levelname)s] %(asctime)s %(name)s %(message)s"))


def getAgentLogger(name: str, level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.propagate = False
    logger.setLevel(level)
    for handler in logger.handlers:
        logger.removeHandler(handler)
    logger.addHandler(_handler)
    return logger
