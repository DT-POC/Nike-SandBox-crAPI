import time
from logging import getLogger
from typing import Any
from typing import TYPE_CHECKING
from uuid import uuid4

from falcon import HTTPError

from apiprotect.audit import audit_event
from apiprotect.events import InboundHttpRequestEvent
from apiprotect.events import InboundHttpRequestResponseEvent
from apiprotect.exceptions import PolicyViolationError
from apiprotect.middleware.common import BaseApiProtectMiddleware
from apiprotect.middleware.local_context import ctx
from apiprotect.requests import InboundRequestResponse
from apiprotect.requests.falcon import from_falcon_request
from apiprotect.requests.falcon import patch_falcon_request_streams
from apiprotect.utils import log_and_suppress

if TYPE_CHECKING:
    from falcon import Request
    from falcon import Response


_logger = getLogger(__name__)


class ApiProtectFalconMiddleware(BaseApiProtectMiddleware):
    """A Falcon middleware the provides Api Protection.

    This middleware should be added after any logging middleware and before other
    middleware or application code.


                                        Request Flow

                                            │
    ┌───────────────────────────────────┐   │
    │        Logging Middleware         │   │
    └───────────────────────────────────┘   │
    ┌───────────────────────────────────┐   │
    │      Api Protect Middleware       │   │
    └───────────────────────────────────┘   │
    ┌───────────────────────────────────┐   │
    │         Other Middleware          │   │
    └───────────────────────────────────┘   │
                                            │
                                            ▼
    """

    def process_request(self, req: "Request", resp: "Response") -> None:
        if not self.api_protect_is_active:
            return
        try:
            request_id = str(uuid4())
            ctx.request_id = request_id

            self._refresh_config()

            patch_falcon_request_streams(req)

            inbound_http_request_event = InboundHttpRequestEvent(
                request_id=request_id, time=time.time(), record=from_falcon_request(request_id, req)
            )
            audit_result = audit_event(inbound_http_request_event, self.config)

            with log_and_suppress(Exception, logger=_logger):
                ctx.put_event(audit_result)

            audit_result.raise_if_block()

        except PolicyViolationError as e:
            _logger.warning(f"API Protect blocked request: {e}")
            raise HTTPError(status=400)
        except Exception as e:
            _logger.warning(f"API Protect handled error: {e}")

    def process_response(self, req: "Request", resp: "Response", resource: Any, req_succeeded: bool) -> None:
        if not self.api_protect_is_active:
            return
        try:
            request_id = ctx.request_id
            if request_id:
                inbound_http_request_response_event = InboundHttpRequestResponseEvent(
                    request_id=request_id,
                    time=time.time(),
                    record=InboundRequestResponse(request_id=request_id, status_code=str(resp.status)),
                )
                ctx.put_event(inbound_http_request_response_event)

        except PolicyViolationError as e:
            _logger.warning(f"API Protect blocked inbound request: {e}")
            raise HTTPError(status=400)
        except Exception as e:
            _logger.info(f"API Protect handled error: {e}")
        finally:
            with log_and_suppress(Exception, logger=_logger):
                log_batch = ctx.events
                if log_batch:
                    self.event_queue.put_nowait(log_batch)
            # clear request_id and event_logs from local storage
            ctx.reset()
