import logging
import time
from typing import Any
from typing import Callable
from typing import Iterable
from typing import List
from typing import Optional
from typing import Tuple
from typing import TYPE_CHECKING
from uuid import uuid4

from apiprotect.audit import audit_event
from apiprotect.events import InboundHttpRequestEvent
from apiprotect.events import InboundHttpRequestResponseEvent
from apiprotect.exceptions import PolicyViolationError
from apiprotect.middleware.common import BaseApiProtectMiddleware
from apiprotect.middleware.local_context import ctx
from apiprotect.requests import InboundRequestResponse
from apiprotect.requests.wsgi import from_wsgi_environ
from apiprotect.requests.wsgi import patch_wsgi_input
from apiprotect.utils import log_and_suppress

if TYPE_CHECKING:
    from queue import SimpleQueue

    from _typeshed.wsgi import StartResponse
    from _typeshed.wsgi import WSGIApplication
    from _typeshed.wsgi import WSGIEnvironment

    from apiprotect.config import ApiProtectConfigurationV2

_logger = logging.getLogger(__name__)


class ApiProtectWSGIMiddleware(BaseApiProtectMiddleware):
    """A WSGI middleware that provides Api Protection.

    This middleware should be added after any logging middleware and before other
    middleware or application code.


                                        Request Flow

                                            │
    ┌───────────────────────────────────┐   │
    │        Logging Middleware         │   │
    └───────────────────────────────────┘   │
    ┌───────────────────────────────────┐   │
    │      Api Protect Middleware       │   │
    └───────────────────────────────────┘   │
    ┌───────────────────────────────────┐   │
    │         Other Middleware          │   │
    └───────────────────────────────────┘   │
                                            │
                                            ▼
    """

    def __init__(
        self,
        app: "WSGIApplication",
        client_id: Optional[str] = None,
        config: Optional["ApiProtectConfigurationV2"] = None,
        config_queue: Optional["SimpleQueue"] = None,
        event_queue: Optional["SimpleQueue"] = None,
        should_validate_client_id: bool = True,
        should_start_threads: bool = True,
        should_register_signal_handlers: bool = True,
        should_register_audit_hook: bool = True,
        should_instrument_http: bool = True,
    ) -> None:
        # store wsgi application
        self.app = app
        self.api_protect_is_active = False
        # init
        super().__init__(
            client_id=client_id,
            config=config,
            config_queue=config_queue,
            event_queue=event_queue,
            should_validate_client_id=should_validate_client_id,
            should_start_threads=should_start_threads,
            should_register_signal_handlers=should_register_signal_handlers,
            should_register_audit_hook=should_register_audit_hook,
            should_instrument_http=should_instrument_http,
        )

    def __call__(self, environ: "WSGIEnvironment", start_response: "StartResponse") -> Iterable[bytes]:
        if not self.api_protect_is_active:
            return self.app(environ, start_response)
        try:
            patch_wsgi_input(environ)

            request_id = str(uuid4())
            ctx.request_id = request_id

            self._refresh_config()

            inbound_http_request_event = InboundHttpRequestEvent(
                request_id=request_id, time=time.time(), record=from_wsgi_environ(request_id, environ)
            )
            audit_result = audit_event(inbound_http_request_event, self.config)

            with log_and_suppress(Exception, logger=_logger):
                ctx.put_event(audit_result)

            audit_result.raise_if_block()

            def custom_start_response(
                status: str, headers: List[Tuple[str, str]], exc_info: Any = None
            ) -> Callable[[bytes], object]:
                with log_and_suppress(Exception, logger=_logger):
                    request_id = ctx.request_id
                    if request_id:
                        status_code = status.split()[0]
                        inbound_http_request_response_event = InboundHttpRequestResponseEvent(
                            request_id=request_id,
                            time=time.time(),
                            record=InboundRequestResponse(request_id=request_id, status_code=status_code),
                        )
                        ctx.put_event(inbound_http_request_response_event)

                return start_response(status, headers, exc_info)

            return self.app(environ, custom_start_response)

        except PolicyViolationError as e:
            _logger.warning(f"API Protect blocked inbound request: {e}")
            start_response("400 Bad Request", [("Content-Type", "text/plain")])
            return [b""]
        except Exception as e:
            _logger.warning(f"API Protect Middleware Error: {e}")
            return self.app(environ, start_response)
        finally:
            with log_and_suppress(Exception, logger=_logger):
                events = ctx.events
                if events:
                    self.event_queue.put_nowait(ctx.events)
            ctx.reset()
