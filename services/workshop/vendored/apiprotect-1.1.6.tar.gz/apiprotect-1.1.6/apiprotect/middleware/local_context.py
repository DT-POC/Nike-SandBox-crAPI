from collections import deque
from contextvars import ContextVar
from logging import getLogger
from typing import List
from typing import Optional
from typing import TYPE_CHECKING
from typing import Union

from typing_extensions import TypedDict

if TYPE_CHECKING:
    from apiprotect.audit import AuditResult
    from apiprotect.events import LoggableEventType

_logger = getLogger(__name__)

DEQUE_MAX_LEN = 2000


class Storage(TypedDict):
    request_id: Optional[str]
    event_log_buffer: deque  # use deque to bound memory consumption


def _empty_storage() -> Storage:
    return {"request_id": None, "event_log_buffer": deque(maxlen=DEQUE_MAX_LEN)}


_local_storage: ContextVar[Storage] = ContextVar("local_storage")


class LocalRequestContext:
    """Local request context that works with threading, asyncio, and greenlets.

    Provide access to request_id and event logs to sys.audit callback and avoid
    problems trying to store things on on custom request or context classes.

    """

    __slots__ = "_storage"

    def __init__(self) -> None:
        self._storage = _local_storage
        self.reset()

    def reset(self) -> None:
        """Reset storage between requests."""
        self._storage.set(_empty_storage())

    def put_event(self, event: Union["LoggableEventType", "AuditResult"]) -> None:
        """Store request event."""
        values = self._storage.get(_empty_storage())
        ctx_request_id = values["request_id"]
        if ctx_request_id is None:
            _logger.info("Cannot put event if request_id unset")
            return
        event_request_id = getattr(event, "request_id", False)
        if event_request_id is False:
            _logger.info("Cannot put event without a request_id")
            return
        if event_request_id != ctx_request_id:
            _logger.info(f"Cannot put event with different request_ids. event:{event_request_id} ctx:{ctx_request_id}")
            return
        values["event_log_buffer"].append(event)
        self._storage.set(values)

    @property
    def events(self) -> List:
        """List of all request events."""
        return list(self._storage.get(_empty_storage())["event_log_buffer"])

    @property
    def request_id(self) -> Optional[str]:
        """Get request_id."""
        return self._storage.get(_empty_storage())["request_id"]

    @request_id.setter
    def request_id(self, request_id: str) -> None:
        """Set request_id."""
        values = self._storage.get(_empty_storage())
        if values["request_id"] is not None or values["event_log_buffer"]:
            _logger.warning("Setting request_id when request_is is set. resetting")
            self.reset()
            reset_values = self._storage.get()
            reset_values["request_id"] = request_id
            self._storage.set(reset_values)
        else:
            values["request_id"] = request_id
            self._storage.set(values)


ctx = LocalRequestContext()
