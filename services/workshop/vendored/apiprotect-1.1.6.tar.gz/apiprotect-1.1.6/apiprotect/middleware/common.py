import signal
import sys
import threading
from logging import getLogger
from queue import Empty as QueueEmpty
from queue import SimpleQueue
from threading import Thread
from typing import Any
from typing import Optional

import apiprotect.config.manager
import apiprotect.reports.manager
from apiprotect.client import ApiProtectClient
from apiprotect.config.models import ApiProtectConfigurationV2
from apiprotect.config.models import SDKConfig
from apiprotect.events.system import ShutdownEvent

_logger = getLogger(__name__)


class BaseApiProtectMiddleware:
    """Base API Protect Middleware."""

    def __init__(
        self,
        client_id: Optional[str] = None,
        config: Optional[ApiProtectConfigurationV2] = None,
        config_queue: Optional[SimpleQueue] = None,
        event_queue: Optional[SimpleQueue] = None,
        should_validate_client_id: bool = True,
        should_start_threads: bool = True,
        should_register_signal_handlers: bool = True,
        should_register_audit_hook: bool = True,
        should_instrument_http: bool = True,
    ) -> None:
        # set middleware off by default
        self.api_protect_is_active = False

        # client_id may passed as a param to this function or
        # read from an environment var `DT_API_PROTECT_CLIENT_ID`
        if client_id is not None:
            self.sdk_config = SDKConfig(client_id=client_id)
        else:
            self.sdk_config = SDKConfig()

        if should_validate_client_id and not ApiProtectClient.client_id_is_valid(
            self.sdk_config.client_id, self.sdk_config.config_url
        ):
            _logger.error(
                f"Client Id {client_id} is not authorized."
                "To avoid this error, use a valid `client_id` *or* turn off API Protect "
                "by not setting the `client_id` parameter when initializing "
                f"{self.__class__.__name__} or unsetting the 'DT_API_PROTECT_CLIENT_ID' "
            )

        if self.sdk_config.debug:
            _logger.info(f"SDK Config: {self.sdk_config!r}")

        if self.sdk_config.deactivate:
            _logger.warning("API Protect deactivated because `DT_API_PROTECT_DEACTIVATE` is set... skipping")
            return

        if not self.sdk_config.client_id or self.sdk_config.client_id == "unknown":
            _logger.warning(
                f"API Protect cannot initialize without a `client_id`. Either "
                f"pass the `client_id` parameter when initializing "
                f"{self.__class__.__name__} or set the 'DT_API_PROTECT_CLIENT_ID' "
                "Environment variable. API Protect inactive."
            )
            return

        _logger.warning(
            "Loading API Protect. To disable API Protect, unset env var "
            "`DT_API_PROTECT_CLIENT_ID` or set `DT_API_PROTECT_DEACTIVATE=1`"
        )

        self._init_config_management_thread(config_queue=config_queue)
        self._init_report_management_thread(event_queue=event_queue)
        if should_start_threads is True:
            self.config_manager_thread.start()
            self.report_manager_thread.start()

        self._load_protection_config(config=config)

        if should_register_signal_handlers:
            _logger.debug("registering signal handlers")
            self._register_signal_handlers()

        if should_register_audit_hook:
            if sys.version_info < (3, 8):
                _logger.debug(f"skipping audit hook registration because python {sys.version_info} is < 3.8")
            else:
                _logger.debug("registering audit hook")
                self._register_audit_hook()

        if should_instrument_http:
            if sys.version_info < (3, 8):
                _logger.debug(f"skipping http instrumentation because python {sys.version_info} is < 3.8")
            else:
                _logger.debug("instrumenting http libs")
                self._instrument_http()

        # initialization complete, turn on protection
        _logger.info("API Protect Enabled")
        self.api_protect_is_active = True

    def shutdown(self, shutdown_event: Optional[ShutdownEvent] = None) -> None:
        _logger.warning("Shutting down")
        shutdown_event = shutdown_event or ShutdownEvent()
        self.event_queue.put_nowait(shutdown_event)
        self.stop_event.set()

    def _register_signal_handlers(self) -> None:
        # register signal handler
        if threading.current_thread() is not threading.main_thread():
            _logger.info("Skipping signal handler registration because this isn't main thread")
            return

        def signal_handler(sig: int, frame: Any) -> None:
            signal_name = signal.strsignal(sig)
            _logger.warning(f"Received Signal: {signal_name}")
            shutdown_event = ShutdownEvent(record=f"{signal_name}")
            self.shutdown(shutdown_event)
            sys.exit()

        try:
            signal.signal(signal.SIGINT, signal_handler)
            signal.signal(signal.SIGTERM, signal_handler)
        except Exception as e:
            _logger.warning(f"Skipping signal handler registration: {e}")

    def _load_protection_config(self, config: Optional[ApiProtectConfigurationV2] = None) -> None:
        # use config passed to __init__ if valid
        if isinstance(config, ApiProtectConfigurationV2):
            self.config = config
            return

        # use default config
        self.config = ApiProtectConfigurationV2()

        # try to load a remote config to replace default config
        try:
            self.config = self.config_queue.get(timeout=5.0)
        except QueueEmpty:
            # this should not normally happen
            _logger.warning("API Protect could not load a config, using default observability config")

    def _refresh_config(self) -> None:
        # get_nowait uses semaphore so only read from queue if we need to
        if self.config and self.config.expired():
            try:
                new_config = self.config_queue.get_nowait()
                self.config = new_config
            except QueueEmpty:
                # no new config available, continue using current config
                pass

    def _init_config_management_thread(self, config_queue: Optional[SimpleQueue] = None) -> None:
        # init configuration management thread
        self.config_queue: SimpleQueue = config_queue or SimpleQueue()
        self.stop_event = threading.Event()
        self.config_manager_thread = Thread(
            target=apiprotect.config.manager.run_forever,
            daemon=True,
            name="config-manager-thread",
            args=(
                self.config_queue,
                self.stop_event,
                self.sdk_config.client_id,
                self.sdk_config.config_url,
                self.sdk_config.config_timeout,
            ),
            kwargs={"debug": self.sdk_config.debug},
        )

    def _init_report_management_thread(self, event_queue: Optional[SimpleQueue] = None) -> None:
        self.event_queue: SimpleQueue = event_queue or SimpleQueue()
        self.report_manager_thread = Thread(
            target=apiprotect.reports.manager.run_forever,
            name="report-manager-thread",
            daemon=True,
            args=(
                self.event_queue,
                self.sdk_config.client_id,
                self.sdk_config.report_url,
                self.sdk_config.report_timeout,
            ),
            kwargs={"debug": self.sdk_config.debug},
        )

    def _register_audit_hook(self) -> None:
        if sys.version_info < (3, 8):
            _logger.debug(f"skipping _register_audit_hook because python {sys.version_info} is < 3.8")
            return
        else:
            from apiprotect.instrumentation import register_sys_audit_hook

            register_sys_audit_hook(self.config)

    def _instrument_http(self) -> None:
        if sys.version_info > (3, 8):
            _logger.debug(f"skipping _instrument_http because python {sys.version_info} is < 3.8")
            return
        else:
            from apiprotect.instrumentation import instrument_http_client_connection

            instrument_http_client_connection()
