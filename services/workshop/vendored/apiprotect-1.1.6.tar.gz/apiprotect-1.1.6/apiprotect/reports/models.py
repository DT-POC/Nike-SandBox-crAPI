import logging
import time
from enum import Enum
from typing import Any
from typing import Dict
from typing import List
from typing import Optional

from pydantic import BaseModel
from pydantic import Field
from pydantic import validator

from apiprotect.audit import AuditResult
from apiprotect.checks.models import InboundRequestBlockedReasonEnum
from apiprotect.events.network import InboundHttpRequestEvent
from apiprotect.omit_auth import omit_cookies_auth
from apiprotect.omit_auth import omit_headers_auth
from apiprotect.omit_auth import omit_query_params_auth
from apiprotect.omit_auth import omit_query_string_auth
from apiprotect.requests import InboundRequest
from apiprotect.version import __version__ as SDK_VERSION

_logger = logging.getLogger(__name__)


class EventActionTypeEnum(str, Enum):
    BLOCK = "BLOCK"
    LOG = "LOG"


class ProtectEventTypeEnum(str, Enum):
    AUTHENTICATION = "AUTHENTICATION"
    AUTHORIZATION = "AUTHORIZATION"
    BOLA_ATTACK = "BOLA_ATTACK"
    BOT_DETECTED = "BOT_DETECTED"
    ENCRYPTION = "ENCRYPTION"
    SOCKET_CONNECT = "SOCKET_CONNECT"
    SOCKET_GETADDRINFO = "SOCKET_GETADDRINFO"
    SSRF_ATTACK = "SSRF_ATTACK"
    SQLI_ATTACK = "SQLI_ATTACK"
    XSS_ATTACK = "XSS_ATTACK"
    OUTBOUND_REQUEST = "OUTBOUND_REQUEST"
    INBOUND_REQUEST_RESPONSE = "INBOUND_REQUEST_RESPONSE"


class ProtectEvent(BaseModel):
    event_type: ProtectEventTypeEnum
    event_action: EventActionTypeEnum
    event_context: Optional[Dict[str, Any]]
    event_timestamp: float = Field(default_factory=time.time)


class ApiProtectReportV2(BaseModel):
    # report
    report_id: str
    report_version: int = 2
    start_timestamp: float = Field(default_factory=time.time)
    end_timestamp: Optional[float] = None

    # protection config info
    config_source: Optional[str] = None
    config_version: Optional[int] = None
    config_timestamp: Optional[int] = None

    # sdk config info
    sdk_version: Optional[str] = SDK_VERSION

    # environment
    deployment_info: Dict[str, Any] = Field(default_factory=dict)

    # inbound request
    inbound_request: InboundRequest
    inbound_request_allowed: bool = True
    inbound_request_blocked_reason: Optional[InboundRequestBlockedReasonEnum] = None

    # events
    events: List[ProtectEvent] = Field(default_factory=list)

    # internal logs
    internal_logs: List[str] = Field(default_factory=list)

    def add_socket_connect(
        self,
        socket_class: Optional[str] = None,
        address_family: Optional[str] = None,
        socket_type: Optional[str] = None,
        addr: Optional[tuple] = None,
        action: EventActionTypeEnum = EventActionTypeEnum.LOG,
        timestamp: Optional[float] = None,
    ) -> None:
        event_context = {
            "socket_class": socket_class,
            "address_family": address_family,
            "socket_type": socket_type,
            "addr": str(addr),
        }
        protect_event = ProtectEvent(
            event_type=ProtectEventTypeEnum.SOCKET_CONNECT,
            event_action=action,
            event_timestamp=timestamp or time.time(),
            event_context=event_context,
        )
        self.events.append(protect_event)

    def add_socket_getaddrinfo(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        address_family: Optional[str] = None,
        socket_type: Optional[str] = None,
        protocol: Optional[str] = None,
        action: EventActionTypeEnum = EventActionTypeEnum.LOG,
        timestamp: Optional[float] = None,
    ) -> None:
        event_context = {
            "host": host,
            "port": port,
            "address_family": address_family,
            "socket_type": socket_type,
            "protocol": protocol,
        }
        protect_event = ProtectEvent(
            event_type=ProtectEventTypeEnum.SOCKET_GETADDRINFO,
            event_action=action,
            event_timestamp=timestamp or time.time(),
            event_context=event_context,
        )
        self.events.append(protect_event)

    def add_outbound_request(
        self,
        protocol: Optional[str] = None,
        scheme: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[str] = None,
        method: Optional[str] = None,
        url: Optional[str] = None,
        headers: Optional[dict] = None,
        body: Any = None,
        action: EventActionTypeEnum = EventActionTypeEnum.LOG,
        timestamp: Optional[float] = None,
    ) -> None:
        if url:
            url = omit_query_string_auth(url)
        event_context = {
            "scheme": scheme,
            "host": host,
            "port": port,
            "method": method,
            "url": url,
            "headers": omit_headers_auth(headers),
        }

        protect_event = ProtectEvent(
            event_type=ProtectEventTypeEnum.OUTBOUND_REQUEST,
            event_action=action,
            event_timestamp=timestamp or time.time(),
            event_context=event_context,
        )
        self.events.append(protect_event)

    def add_bola_attack(
        self,
        event_context: Dict[str, str],
        action: EventActionTypeEnum = EventActionTypeEnum.LOG,
        timestamp: Optional[float] = None,
    ) -> None:
        protect_event = ProtectEvent(
            event_type=ProtectEventTypeEnum.BOLA_ATTACK,
            event_action=action,
            event_timestamp=timestamp or time.time(),
            event_context=event_context,
        )
        self.events.append(protect_event)

    def add_bot_detected_event(
        self,
        event_context: Dict[str, str],
        action: EventActionTypeEnum = EventActionTypeEnum.LOG,
        timestamp: Optional[float] = None,
    ) -> None:
        protect_event = ProtectEvent(
            event_type=ProtectEventTypeEnum.BOT_DETECTED,
            event_action=action,
            event_timestamp=timestamp or time.time(),
            event_context=event_context,
        )
        self.events.append(protect_event)

    def add_sqli_attack(
        self,
        event_context: Dict[str, str],
        action: EventActionTypeEnum = EventActionTypeEnum.LOG,
        timestamp: Optional[float] = None,
    ) -> None:

        protect_event = ProtectEvent(
            event_type=ProtectEventTypeEnum.SQLI_ATTACK,
            event_action=action,
            event_timestamp=timestamp or time.time(),
            event_context=event_context,
        )
        self.events.append(protect_event)

    def add_ssrf_attack(
        self,
        event_context: Dict[str, str],
        action: EventActionTypeEnum = EventActionTypeEnum.LOG,
        timestamp: Optional[float] = None,
    ) -> None:

        protect_event = ProtectEvent(
            event_type=ProtectEventTypeEnum.SSRF_ATTACK,
            event_action=action,
            event_timestamp=timestamp or time.time(),
            event_context=event_context,
        )
        self.events.append(protect_event)

    def add_xss_attack(
        self,
        event_context: Dict[str, str],
        action: EventActionTypeEnum = EventActionTypeEnum.LOG,
        timestamp: Optional[float] = None,
    ) -> None:

        protect_event = ProtectEvent(
            event_type=ProtectEventTypeEnum.XSS_ATTACK,
            event_action=action,
            event_timestamp=timestamp or time.time(),
            event_context=event_context,
        )
        self.events.append(protect_event)

    def add_inbound_request_response(
        self,
        status_code: Optional[str] = None,
        headers: Optional[dict] = None,
        action: EventActionTypeEnum = EventActionTypeEnum.LOG,
        timestamp: Optional[float] = None,
    ) -> None:
        event_context = {
            "status_code": status_code,
            "headers": omit_headers_auth(headers),
        }

        protect_event = ProtectEvent(
            event_type=ProtectEventTypeEnum.INBOUND_REQUEST_RESPONSE,
            event_action=action,
            event_timestamp=timestamp or time.time(),
            event_context=event_context,
        )
        self.events.append(protect_event)

    def add_internal_logs(self, logs: List[str]) -> None:
        self.internal_logs.extend(logs)

    @property
    def request_id(self) -> str:
        return self.inbound_request.request_id

    @property
    def is_complete(self) -> bool:
        return self.end_timestamp is not None

    def mark_complete(self, timestamp: Optional[float] = None) -> None:
        self.end_timestamp = timestamp or time.time()

    @validator("inbound_request")
    def make_inbound_request_safe_for_egress(cls, inbound_request: InboundRequest) -> InboundRequest:
        """Remove sensitive information from inbound request before adding to report."""

        # never send body of inbound request
        inbound_request.body = None

        # remove authentication values from query, headers, and cookies
        if inbound_request.query:
            try:
                inbound_request.query = omit_query_params_auth(inbound_request.query)
            except Exception:
                inbound_request.query = None
        if inbound_request.headers:
            try:
                inbound_request.headers = omit_headers_auth(inbound_request.headers)
            except Exception:
                inbound_request.headers = None
        if inbound_request.cookies:
            try:
                inbound_request.cookies = omit_cookies_auth(inbound_request.cookies)
            except Exception:
                inbound_request.cookies = None
        return inbound_request

    @classmethod
    def from_inboundrequest_auditresult(cls, audit_result: AuditResult) -> "ApiProtectReportV2":
        if not isinstance(audit_result.event, InboundHttpRequestEvent):
            raise ValueError("Not an inbound request event: {audit_result.event}")

        inbound_request = audit_result.event.record
        report = cls(
            report_id=inbound_request.request_id,
            config_source=audit_result.config.metadata.source,
            config_version=audit_result.config.version,
            config_timestamp=audit_result.config.metadata.timestamp,  # type: ignore
            inbound_request=inbound_request,
            inbound_request_allowed=audit_result.is_allow,
            inbound_request_blocked_reason=audit_result.result.reason,
        )

        if inbound_request.context and "deployment_info" in inbound_request.context:
            report.deployment_info = inbound_request.context.pop("deployment_info", {})

        for attack in audit_result.result.attacks:
            if attack.type == "SQLI_ATTACK":
                report.add_sqli_attack(event_context=attack.context, timestamp=inbound_request.timestamp)
            elif attack.type == "XSS_ATTACK":
                report.add_xss_attack(event_context=attack.context, timestamp=inbound_request.timestamp)
            elif attack.type == "SSRF_ATTACK":
                report.add_ssrf_attack(event_context=attack.context, timestamp=inbound_request.timestamp)
            elif attack.type == "BOLA_ATTACK":
                report.add_bola_attack(event_context=attack.context, timestamp=inbound_request.timestamp)
            elif attack.type == "BOT_DETECTED":
                report.add_bot_detected_event(event_context=attack.context, timestamp=inbound_request.timestamp)

        if audit_result.is_complete:
            report.mark_complete()

        return report
