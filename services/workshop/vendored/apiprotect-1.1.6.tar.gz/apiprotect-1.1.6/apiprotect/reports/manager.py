import logging
import time
from queue import SimpleQueue
from typing import Dict
from typing import List
from typing import NamedTuple
from typing import Optional
from typing import Tuple
from typing import Union

from apiprotect.audit import AuditResult
from apiprotect.events import LoggableEventType
from apiprotect.events.network import InboundHttpRequestEvent
from apiprotect.events.network import InboundHttpRequestResponseEvent
from apiprotect.events.network import OutboundHttpRequestEvent
from apiprotect.events.network import SocketConnectEvent
from apiprotect.events.network import SocketGetAddrInfoEvent
from apiprotect.events.system import ShutdownEvent
from apiprotect.reports.models import ApiProtectReportV2
from apiprotect.reports.sinks import HttpSink
from apiprotect.reports.sinks import SinkType
from apiprotect.reports.sinks import StreamSink

_logger = logging.getLogger(__name__)

RequestId = str


class ManagedReport(NamedTuple):
    timestamp: float
    report: ApiProtectReportV2

    @property
    def age(self) -> float:
        # time.monotonic may not work with unfrozen lambda
        return time.time() - self.timestamp


class ApiProtectDuplicateReportError(Exception):
    pass


class ApiProtectUnprocessableEventError(Exception):
    pass


class ApiProtectReportIdError(Exception):
    pass


class ApiProtectReportError(Exception):
    pass


class ReportManager:
    """Creates, stores, and delivers complete reports to report Sinks.

    Reports may need to be stored temporarily while related events arrive. The
    ReportManager handles short term storage, and when an report is complete,
    it delivers the complete Report to all the its configured Sinks.
    The configured Sink then handles forwarding the report to the console or
    Data Theorem's services.

    To be flexible the ReportManager doesn't read events from Queues directly,
    it is inteneded to be created in the context of a separate thread or process
    that knows how to read events.

    """

    def __init__(
        self,
        client_id: str,
        report_url: str,
        report_timeout: float,
        report_sinks: Optional[List[SinkType]] = None,
        max_reports: int = 100,
        max_report_age_secs: int = 60 * 60,
        debug: bool = False,
    ):
        self.client_id = client_id
        self.report_url = report_url
        self.report_timeout = report_timeout
        self._reports: Dict[str, ManagedReport] = {}

        self.max_reports = max_reports
        self.max_reports_age_secs = max_report_age_secs
        self.debug = debug

        self.report_sinks = report_sinks or self.default_sinks()

    def default_sinks(self) -> List[SinkType]:
        _logger.debug("using default sinks")
        if self.debug:
            return [
                StreamSink(),
                HttpSink(url=self.report_url, timeout=self.report_timeout, client_id=self.client_id),
            ]
        else:
            return [
                HttpSink(url=self.report_url, timeout=self.report_timeout, client_id=self.client_id),
            ]

    def report_count(self) -> int:
        return len(self._reports)

    def complete_reports(self) -> List[Tuple[RequestId, ManagedReport]]:
        return [
            (request_id, managed_report)
            for request_id, managed_report in self._reports.items()
            if managed_report.report.is_complete
        ]

    def oldest_report_id(self) -> Optional[RequestId]:
        if not self._reports:
            return None
        return next(iter(self._reports.keys()))  # woot! dicts insertion-ordered by default

    def oldest_report_age(self) -> Optional[float]:
        try:
            return self._reports[self.oldest_report_id()].age  # type: ignore
        except (KeyError, AttributeError):
            return None

    def expired_reports(self) -> List[Tuple[RequestId, ManagedReport]]:
        oldest_request_id = self.oldest_report_id()
        if not oldest_request_id:
            return []

        if self._reports[oldest_request_id].age > self.max_reports_age_secs:
            return [
                (request_id, managed_report)
                for request_id, managed_report in self._reports.items()
                if managed_report.age > self.max_reports_age_secs
            ]
        return []

    def _handle_audit_result(self, audit_result: AuditResult) -> None:
        request_id = audit_result.request_id
        if isinstance(audit_result.event, InboundHttpRequestEvent):
            if request_id in self._reports:
                raise ApiProtectDuplicateReportError(f"Report with request_id {request_id} already exists")
            report = ApiProtectReportV2.from_inboundrequest_auditresult(audit_result)
            if report:
                self._reports[request_id] = ManagedReport(timestamp=time.time(), report=report)
                _logger.debug(f"created report with request_id: {request_id}")
            else:
                raise ApiProtectReportError(f"unable to create report from {audit_result}")
        elif isinstance(audit_result.event, OutboundHttpRequestEvent):
            if request_id not in self._reports:
                raise ApiProtectReportIdError(f"Unable to find report for audit result {audit_result}")
            _, report = self._reports[request_id]
            record = audit_result.event.record
            kwargs = record.dict(exclude={"requestId"})
            report.add_outbound_request(**kwargs, timestamp=audit_result.event.time.timestamp())
        else:
            raise ApiProtectUnprocessableEventError(f"Unprocessable audit result {audit_result}")

    def _handle_protect_event(self, protect_event: LoggableEventType) -> None:
        try:
            request_id = protect_event.request_id
            _, report = self._reports[request_id]
        except KeyError:
            raise ApiProtectReportIdError(f"Unable to find report for event {protect_event}")

        if isinstance(protect_event, SocketConnectEvent):
            _logger.debug("adding socket.connect event")
            report.add_socket_connect(**protect_event.record.dict())
        elif isinstance(protect_event, SocketGetAddrInfoEvent):
            _logger.debug("adding socket.getaddrinfo event")
            report.add_socket_getaddrinfo(**protect_event.record.dict())
        elif isinstance(protect_event, InboundHttpRequestResponseEvent):
            _logger.debug("adding inbound_request.response event, marking report complete")
            report.add_inbound_request_response(**protect_event.record.dict(exclude={"request_id"}))
            report.mark_complete()
        else:
            raise ApiProtectUnprocessableEventError(f"Unprocessable type {protect_event}")

    def process_event(self, items: List[Union[AuditResult, LoggableEventType]]) -> None:
        """Add events to reports and deliver complete reports.

        This is primary function of the ReportManager. All errors must be swallowed
        or things will break.
        """
        if isinstance(items, AuditResult):
            items = [items]

        for item in items:
            try:
                if isinstance(item, AuditResult):
                    self._handle_audit_result(item)
                else:
                    self._handle_protect_event(item)
            except ApiProtectReportError as e:
                _logger.debug(f"failed to create report for {items}: {e}", exc_info=True)
                break  #
            except (ApiProtectDuplicateReportError, ApiProtectUnprocessableEventError, ApiProtectReportIdError) as e:
                _logger.debug(f"process_event error for {item}: {e}", exc_info=True)

            except Exception as e:
                _logger.debug(f"process_event error for {item}: {e}", exc_info=True)

        # deliver any complete reports
        self.deliver_complete_reports()

        # prune reports excess reports and reports exceeding max_age
        if self.report_count() > 0:
            self.prune()

    def deliver_complete_reports(self) -> None:
        """Delivers complete reports to report sinks."""
        complete_reports = self.complete_reports()
        for request_id, managed_report in complete_reports:
            report = managed_report.report
            for report_sink in self.report_sinks:
                try:
                    report_sink.deliver_report(report)
                except Exception as e:
                    _logger.debug(f"Report sink error: {e}")
            del self._reports[request_id]
            _logger.debug(f"Removed completed report: {report}")

    def prune(self) -> None:
        """Remove undelivered reports if necessary to avoid resource exhaustion.

        This method removed reports if we are storing too many or if the report
        age exceeds the maximum age threshold.

        Report pruning shouldn't happen, if it is, there may be a problem.
        """

        for request_id, managed_report in self.expired_reports():
            _logger.debug(
                f"removing report {request_id} because age {managed_report.age} > {self.max_reports_age_secs}"
            )
            del self._reports[request_id]

        post_expiration_report_count = self.report_count()
        if post_expiration_report_count > self.max_reports:
            oldest_report_id = self.oldest_report_id()
            if not oldest_report_id:
                return
            _logger.debug(
                f"removing report {oldest_report_id} because report count "
                "{post_expiration_report_count} > {self.max_reports}"
            )
            del self._reports[oldest_report_id]

    def shutdown(self) -> None:
        self.deliver_complete_reports()
        _logger.debug("delivered all complete reports")

    def __repr__(self) -> str:
        return (
            f"ReportManager("
            f"report_count={self.report_count()}, "
            f"max_reports={self.max_reports}, "
            f"complete_report_count={len(self.complete_reports())}, "
            f"expired_report_count={len(self.expired_reports())}, "
            f"oldest_report_age={self.oldest_report_age()})"
        )


def run_forever(
    event_queue: SimpleQueue,
    client_id: str,
    report_url: str,
    report_timeout: float,
    report_manager: Optional[ReportManager] = None,
    debug: bool = False,
) -> None:
    """Target of thread or process which copies events from queue to Report Manager.

    Replace this function as necessary for sources other than Python's
    stdlib queues.
    """
    _logger.debug("Starting")
    report_manager = report_manager or ReportManager(
        client_id=client_id, report_url=report_url, report_timeout=report_timeout, debug=debug
    )
    while True:
        event = event_queue.get()  # blocks until event in queue
        _logger.debug(f"Received event: {type(event)}")
        if isinstance(event, ShutdownEvent):
            _logger.info(f"Shutting down report manager thread: {event}")
            report_manager.shutdown()
            break
        else:
            try:
                report_manager.process_event(event)
            except Exception as e:
                _logger.debug(f"error processing event {event} {e}", exc_info=True)
    _logger.debug("stopped")
