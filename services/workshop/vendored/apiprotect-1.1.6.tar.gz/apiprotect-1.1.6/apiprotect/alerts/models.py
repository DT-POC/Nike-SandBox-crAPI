from enum import Enum
from typing import Any
from typing import Dict
from typing import Optional

from pydantic import BaseModel

from apiprotect.version import __version__ as SDK_VERSION


class ProtectAlertTypeEnum(str, Enum):
    VOLUMETRIC_ABUSE_START = "VOLUMETRIC_ABUSE_START"
    VOLUMETRIC_ABUSE_STOP = "VOLUMETRIC_ABUSE_STOP"


class ApiProtectAlert(BaseModel):
    # client info
    sdk_version: Optional[str] = SDK_VERSION

    restful_api_id: str

    alert_id: str  # uuid for dedup
    alert_timestamp: int
    alert_type: ProtectAlertTypeEnum
    alert_context: Dict[str, Any]
