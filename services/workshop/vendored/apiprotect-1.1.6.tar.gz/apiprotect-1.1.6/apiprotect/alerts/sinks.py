import abc
import logging
import sys
from typing import Optional
from typing import TextIO
from typing import Union

import requests

from apiprotect.alerts.models import ApiProtectAlert

_logger = logging.getLogger(__name__)

SinkType = Union["StreamSink", "HttpSink"]


class AbstractAlertSink(abc.ABC):
    """Base class for alert sinks.

    `deliver_alert` is called once from the AlertManager and always returns
    `None`. Batching, Error handling and/or retrying is handled by the sink
    """

    @abc.abstractmethod
    def deliver_alert(self, alert: ApiProtectAlert) -> None:
        pass


class StreamSink(AbstractAlertSink):
    """Print alert to stream for dev/debug only."""

    def __init__(
        self,
        stream: TextIO = sys.stderr,
    ):
        self.stream: TextIO = stream

    def deliver_alert(self, alert: ApiProtectAlert) -> None:
        try:
            print(f"StreamSink.deliver : {alert.json()}", file=self.stream, flush=True)
        except Exception as e:
            _logger.exception(f"Delivery error for {alert!r}: {e}")


class HttpSink(AbstractAlertSink):
    """Http alert sink using bearer token auth."""

    def __init__(
        self,
        url: str,
        timeout: float = 3.0,
        client_id: Optional[str] = None,
        debug: bool = False,
    ):
        self.client_id = client_id
        self.url = url
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})
        if self.client_id:
            self.session.headers.update({"Authorization": f"Bearer {self.client_id}"})
        self.debug = debug

    def deliver_alert(self, alert: ApiProtectAlert) -> None:
        try:
            response = self.session.post(self.url, data=alert.json(), timeout=self.timeout)
            response.raise_for_status()
            _logger.debug(f"HttpSink deliver_alert response: {response}")
        except requests.HTTPError as e:
            if e.response.status_code == 403:
                _logger.error(
                    "Bad/missing client_id. Set `DT_API_PROTECT_CLIENT_ID` "
                    "in environment or pass `client_id` to API Protect middleware."
                )
            else:
                _logger.warning(f"Failed to deliver alert to {self.url}: {e}. Ignoring report {alert!r}")
        except Exception as e:
            _logger.warning(f"Failed to deliver alert to {self.url}: {e}. Ignoring report {alert!r}")
