import logging
from queue import SimpleQueue
from typing import List
from typing import Optional

from apiprotect.alerts.models import ApiProtectAlert
from apiprotect.alerts.sinks import HttpSink
from apiprotect.alerts.sinks import SinkType
from apiprotect.alerts.sinks import StreamSink
from apiprotect.audit import AuditResult
from apiprotect.events.alert import AlertEvent
from apiprotect.events.system import ShutdownEvent
from apiprotect.exceptions import UnprocessableEventError

_logger = logging.getLogger(__name__)


class DuplicateAlertError(Exception):
    pass


class AlertManager:
    """Creates, stores, and delivers alerts to alerts Sinks."""

    def __init__(
        self,
        client_id: str,
        alert_url: str,
        alert_timeout: float,
        alert_sinks: Optional[List[SinkType]] = None,
        debug: bool = False,
    ):
        self.client_id = client_id
        self.alert_url = alert_url
        self.alert_timeout = alert_timeout

        self.debug = debug

        self.alert_sinks = alert_sinks or self.default_sinks()

    def default_sinks(self) -> List[SinkType]:
        _logger.debug("using default sinks")
        if self.debug:
            return [
                StreamSink(),
                HttpSink(url=self.alert_url, timeout=self.alert_timeout, client_id=self.client_id),
            ]
        else:
            return [
                HttpSink(url=self.alert_url, timeout=self.alert_timeout, client_id=self.client_id),
            ]

    def process_event(self, item: AuditResult) -> None:
        """Add events to reports and deliver complete reports.

        This is primary function of the ReportManager. All errors must be swallowed
        or things will break.
        """
        try:
            if isinstance(item, AuditResult):
                _logger.debug("processing AuditResult event")
                if isinstance(item.event, AlertEvent):
                    if not item.result.context:
                        raise UnprocessableEventError(f"Missing context, {item}")
                    if not item.result.alert:
                        raise UnprocessableEventError(f"Missing alert, {item}")

                    alert = ApiProtectAlert(
                        restful_api_id=item.result.context["restful_api_id"],
                        alert_id=item.event.request_id,
                        alert_timestamp=item.result.context["timestamp"],
                        alert_type=item.result.alert.type,
                        alert_context=item.result.alert.context,
                    )
                else:
                    raise UnprocessableEventError(f"Unprocessable type {item}")
            else:
                raise UnprocessableEventError(f"Unprocessable type {item}")

            # deliver alert
            self.deliver_alert(alert)

        except UnprocessableEventError as e:
            _logger.exception(f"process_event error: {e}")
        except Exception as e:
            _logger.exception(f"process_event error: {e}")

    def deliver_alert(self, alert: ApiProtectAlert) -> None:
        """Delivers complete reports to report sinks."""
        for alert_sink in self.alert_sinks:
            try:
                alert_sink.deliver_alert(alert)
            except Exception as e:
                _logger.debug(f"Report sink error: {e}")

    def shutdown(self) -> None:
        _logger.debug("delivered all complete reports")


def run_forever(
    alert_queue: SimpleQueue,
    client_id: str,
    alert_url: str,
    alert_timeout: float,
    alert_manager: Optional[AlertManager] = None,
    debug: bool = False,
) -> None:
    """Target of thread or process which copies events from queue to alert Manager.

    Replace this function as necessary for sources other than Python's
    stdlib queues.
    """
    _logger.debug("Starting")
    alert_manager = alert_manager or AlertManager(
        client_id=client_id, alert_url=alert_url, alert_timeout=alert_timeout, debug=debug
    )
    while True:
        alert = alert_queue.get()
        _logger.debug(f"Received alert: {type(alert)}")
        if isinstance(alert, ShutdownEvent):
            _logger.info(f"Shutting down alert manager thread: {alert}")
            alert_manager.shutdown()
            break
        else:
            alert_manager.deliver_alert(alert)
    _logger.debug("stopped")
