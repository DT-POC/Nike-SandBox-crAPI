import base64
import json
import logging
import time
from ipaddress import IPv4Network
from typing import Any
from typing import Dict
from typing import Optional
from typing import Union

import fnc.mappings
from aws_lambda_powertools.utilities.parser.models import APIGatewayProxyEventModel
from aws_lambda_powertools.utilities.parser.models import APIGatewayProxyEventV2Model
from falcon.request_helpers import parse_cookie_header

from apiprotect.events.awslambda import LambdaContext
from apiprotect.requests import InboundRequest
from apiprotect.utils import case_insensitive_mapping_lookup

_logger = logging.getLogger(__name__)


def parse_api_gateway_event(event: Any) -> Optional[Union[APIGatewayProxyEventModel, APIGatewayProxyEventV2Model]]:
    """Return parsed API Gateway event based on API Gateway type.

    A lambda can receive three types of events from the two versions of an AWS API Gateway:
    - API Gateway Version 1 Format, aka a "REST" API Gateway
    - API Gateway Version 2 Format, aka an "HTTP" API Gateway
    - Raw request from Version 1 Gateway when using "LAMBDA" integration type

    Note that an API Gateway V2 can be configured to send events in V1 format

    How to determine API Gateway type:
    - via console at console.aws.amazon.com/apigateway/main/apis under "Protocol"
      -  "REST" is V1
      -  "HTTP" is V2
    - via aws cli:
      -  `aws apigateway get-rest-apis` for V1
      -  `aws apigatewayv2 get-apis` for V2

    An REST API Gateway, aka API Gateway V1, supports custom mapping
    of body parameters. It also has a default mapping template for json
    requests.

    Docs about the different event formats:
    https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-develop-integrations-lambda.html

    """

    try:
        return APIGatewayProxyEventV2Model.parse_obj(event)
    except Exception:
        pass
    try:
        return APIGatewayProxyEventModel.parse_obj(event)
    except Exception:
        pass
    return None


def from_awslambda_handler_args(
    event: Dict[str, Any], lambda_context: LambdaContext, request_id: Optional[str] = None
) -> InboundRequest:
    try:
        parsed_event = parse_api_gateway_event(event)
        if not parsed_event:
            return InboundRequest(request_id=lambda_context.aws_request_id, context=lambda_context)
    except Exception as e:
        _logger.warning("Unknown event type, using bare event. event: %s, error:%s", event, e)
        return InboundRequest(request_id=lambda_context.aws_request_id)
    if isinstance(parsed_event, APIGatewayProxyEventV2Model):
        try:
            inbound_request = from_apigatewayv2_event(parsed_event, lambda_context)
            if inbound_request:
                return inbound_request
        except Exception as e:
            _logger.warning("Unknown event type, using bare event. event: %s, error:%s", event, e)
    elif isinstance(parsed_event, APIGatewayProxyEventModel):
        try:
            inbound_request = from_apigatewayv1_event(parsed_event, lambda_context)
            if inbound_request:
                return inbound_request
        except Exception as e:
            _logger.warning("Unknown event type, using bare event. event: %s, error:%s", event, e)

    # In this case, it is either an api gateway v1 custom event with an
    # unknown custom mapping or the lambda was called with an unsupported
    # event like an SNS notification so we return a blank InboundRequestDetails
    return InboundRequest(request_id=lambda_context.aws_request_id)


def from_apigatewayv1_event(event: APIGatewayProxyEventModel, lambda_context: LambdaContext) -> "InboundRequest":
    auth_id = fnc.mappings.get("requestContext.authorizer.claims.email", event)
    if auth_id is None:
        auth_id = fnc.mappings.get("requestContext.identity.cognito_identity_id", event)

    timestamp = fnc.mappings.get("event.requestContext.requestTimeEpoch", event) or time.time()
    content_type = case_insensitive_mapping_lookup(event.headers, "Content-Type")
    scheme = case_insensitive_mapping_lookup(event.headers, "X-Forwarded-Proto", "https")
    port = case_insensitive_mapping_lookup(event.headers, "X-Forwarded-Port", "443")
    host = event.requestContext.domainName or case_insensitive_mapping_lookup(event.headers, "Host")
    content_length = case_insensitive_mapping_lookup(event.headers, "content-length")

    cookies = None
    try:
        cookies = parse_cookie_header(case_insensitive_mapping_lookup(event.headers, "cookie"))
    except Exception as e:
        _logger.debug(f"Error parsing cookie header: {e}")

    body = event.body
    if event.isBase64Encoded and isinstance(body, str):
        body = base64.b64decode(body.encode()).decode()

    parsed_body = body
    if body:
        try:
            parsed_body = json.loads(body)  # type: ignore
        except Exception as e:
            _logger.debug(f"Unable to parse API Gateway V1 body: {e}")

    if isinstance(event.requestContext.identity.sourceIp, IPv4Network):
        source_ip = str(event.requestContext.identity.sourceIp.network_address)
    else:
        source_ip = str(event.requestContext.identity.sourceIp)

    context = {
        "request_context": event.requestContext,
        "lambda_context": lambda_context,
        "deployment_info": {
            "cloud_provider": "AMAZON_WEB_SERVICES",
            "aws_lambda_arn": lambda_context.invoked_function_arn,
            "aws_api_gateway_api_stage_name": event.requestContext.stage,
            "aws_api_gateway_api_id": event.requestContext.apiId,
        },
    }

    return InboundRequest(
        request_id=lambda_context.aws_request_id,
        timestamp=timestamp,
        protocol=event.requestContext.protocol,
        method=event.httpMethod,
        host=host,
        port=port,
        path=event.path,
        query=event.queryStringParameters,
        # fragment
        headers=event.headers,
        body=body,
        parsed_body=parsed_body,
        scheme=scheme,
        context=context,
        source_ip_address=source_ip,
        auth_id=auth_id,
        user_agent=event.requestContext.identity.userAgent,
        content_type=content_type,
        content_length=content_length,
        cookies=cookies,
        forwarded=None,
        forwarded_scheme=scheme,
    )


def from_apigatewayv2_event(event: APIGatewayProxyEventV2Model, lambda_context: LambdaContext) -> "InboundRequest":

    auth_id = fnc.mappings.get("requestContext.authorizer.jwt.claim.email", event)
    timestamp = fnc.mappings.get("event.requestContext.timeEpoch", event) or time.time()
    content_length = case_insensitive_mapping_lookup(event.headers, "content-length")
    content_type = case_insensitive_mapping_lookup(event.headers, "content-type")
    scheme = case_insensitive_mapping_lookup(event.headers, "x-forwarded-proto", "https")
    port = case_insensitive_mapping_lookup(event.headers, "x-forwarded-port", "443")

    cookies = None
    try:
        cookies = parse_cookie_header(case_insensitive_mapping_lookup(event.headers, "cookie"))
    except Exception as e:
        _logger.debug(f"Error parsing cookie header: {e}")

    body = event.body
    if event.isBase64Encoded and isinstance(body, str):
        body = base64.b64decode(body.encode()).decode()

    parsed_body = body
    if body:
        try:
            parsed_body = json.loads(body)  # type: ignore
        except Exception as e:
            _logger.debug(f"Unable to parse API Gateway V1 body: {e}")

    if isinstance(event.requestContext.http.sourceIp, IPv4Network):
        source_ip = str(event.requestContext.http.sourceIp.network_address)
    else:
        source_ip = str(event.requestContext.http.sourceIp)

    context = {
        "request_context": event.requestContext,
        "lambda_context": lambda_context,
        "deployment_info": {
            "cloud_provider": "AMAZON_WEB_SERVICES",
            "aws_lambda_arn": lambda_context.invoked_function_arn,
            "aws_api_gateway_api_stage_name": event.requestContext.stage,
            "aws_api_gateway_api_id": event.requestContext.apiId,
        },
    }

    return InboundRequest(
        request_id=lambda_context.aws_request_id,
        timestamp=timestamp,
        protocol=event.requestContext.http.protocol,
        method=event.requestContext.http.method,
        host=event.requestContext.domainName,
        port=port,
        path=event.requestContext.http.path,
        query=event.queryStringParameters,
        fragment=None,
        headers=event.headers,
        body=body,
        parsed_body=parsed_body,
        scheme=scheme,
        context=context,
        source_ip_address=source_ip,
        auth_id=auth_id,
        user_agent=event.requestContext.http.userAgent,
        content_type=content_type,
        content_length=content_length,
        cookies=cookies,
        forwarded=None,
        forwarded_scheme=scheme,
    )
