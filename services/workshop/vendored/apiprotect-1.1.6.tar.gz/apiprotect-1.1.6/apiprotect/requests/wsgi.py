import io
import logging
from typing import TYPE_CHECKING

from falcon.request import Request as FalconRequest

from apiprotect.requests import InboundRequest
from apiprotect.requests.falcon import from_falcon_request

if TYPE_CHECKING:
    from _typeshed.wsgi import WSGIEnvironment

_logger = logging.getLogger(__name__)


def patch_wsgi_input(environ: "WSGIEnvironment") -> "WSGIEnvironment":
    """Patch wsgi.input file-like object to allow multiple reads."""
    try:
        # If Content-Length happens to be 0, '',  or the header is
        # missing altogether, this will not block.
        try:
            content_length = int(environ.get("CONTENT_LENGTH"))  # type: ignore
        # handle wsgi environ type and value errors, see Django WSGIRequest
        except (ValueError, TypeError):
            content_length = 0
        environ["wsgi.input"] = io.BytesIO(initial_bytes=environ["wsgi.input"].read(content_length))
    except Exception as e:
        _logger.warning(f"Error mirroring wsgi.input: {e}")

    return environ


def from_wsgi_environ(request_id: str, environ: "WSGIEnvironment") -> InboundRequest:
    body = environ.get("wsgi.input", io.BytesIO()).getvalue()
    falcon_request = FalconRequest(environ)
    return from_falcon_request(request_id, falcon_request, body)
