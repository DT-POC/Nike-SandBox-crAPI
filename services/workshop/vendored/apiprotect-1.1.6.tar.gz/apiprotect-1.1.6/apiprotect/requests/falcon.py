import io
import logging
from typing import Any
from typing import Dict
from typing import Optional

from falcon import Request as FalconRequest
from falcon.constants import _UNSET
from falcon.errors import HTTPInvalidHeader
from falcon.errors import HTTPUnsupportedMediaType
from falcon.errors import MediaMalformedError
from falcon.errors import MediaNotFoundError
from falcon.media.handlers import Handlers
from falcon.stream import BoundedStream

from apiprotect.omit_auth import get_authentication_header_scheme
from apiprotect.requests import InboundRequest

_logger = logging.getLogger(__name__)

MEDIA_HANDLERS = Handlers()


def _parse_body(request: FalconRequest, body: Optional[bytes] = None) -> Any:
    if request._media is not _UNSET:
        _logger.debug(f"parse_body returning request._media: {request._media}")
        return request._media

    if body is None:
        if isinstance(request.stream, io.BytesIO):
            body = request.stream.getvalue()
        else:
            _logger.debug(f"Unable to parse body, request.stream is {type(request.stream)} not io.BytesIO")
            return None

    # empty body means no parsed_body
    if not body:
        _logger.debug("Unable to parse body, body is empty")
        return None

    parsed_body = None

    try:
        handler, _, _ = MEDIA_HANDLERS._resolve(request.content_type, None)
        parsed_body = handler._deserialize(body)
    except HTTPUnsupportedMediaType as e:
        _logger.debug(f"Unable to deserailize body with unsuppported content_type {request.content_type}: {e}")
    except MediaMalformedError as e:
        _logger.debug(f"Unable to deserailize malformed body with content_type {request.content_type}: {e}")
    except MediaNotFoundError as e:
        _logger.debug(f"Unable to deserailize missing body with content_type {request.content_type}: {e}")
    except Exception as e:
        _logger.debug(f"Unexpected error while deserailizing body with content_type {request.content_type}: {e}")

    return parsed_body


def patch_falcon_request_streams(request: FalconRequest) -> FalconRequest:
    """Patch Falcon Request stream object to allow multiple reads."""

    if (
        request.options.auto_parse_form_urlencoded
        and request.content_type is not None
        and "application/x-www-form-urlencoded" in request.content_type
        and request.method not in ("GET", "HEAD")
    ):
        # stream already read
        _logger.debug("Not patching request.stream because request.options.auto_parse_form_urlencoded")
        return request

    if isinstance(request.stream, io.BytesIO):
        # nothing to do here
        _logger.debug("Not patching request.stream because stream is io.BytesIO")
        return request

    if request._bounded_stream:
        _logger.debug(
            f"BoundedStream stream={request._bounded_stream.stream} "
            f"stream_len={request._bounded_stream.stream_len} "
            f"_bytes_remaining={request._bounded_stream._bytes_remaining} "
            f"is_exhausted={request._bounded_stream.is_exhausted}"
        )
        if request._bounded_stream.stream_len != request._bounded_stream._bytes_remaining:
            # bounded_stream initialized and some or all bytes read, nothing we can do
            _logger.debug("Not patching request.stream because _bounded_stream partially read")
            return request

    # replace request.stream with an in-memory buffer that we can access without
    # exhausting stream before protected app can use it
    try:
        buffer = io.BytesIO(request.bounded_stream.read())
    except HTTPInvalidHeader as e:
        # raised before we read from input stream it is ok to return here
        _logger.debug(f"Not patching request.stream because of bad header: {e}")
        return request
    except Exception as e:
        # may have read from input stream
        _logger.warning(f"Error while mirroring input stream: {e}")
        return request
    else:
        _logger.debug("Patching request.stream")
        request.stream = buffer
        request._bounded_stream = BoundedStream(buffer, len(buffer.getvalue()))  # reset bounded_stream

    return request


def from_falcon_request(
    request_id: str,
    request: FalconRequest,
    body: Optional[bytes] = None,
    parsed_body: Any = None,
    context: Optional[Dict[str, Any]] = None,
) -> InboundRequest:
    context = context or dict()

    if body is None:
        if isinstance(request.stream, io.BytesIO):
            body = request.stream.getvalue()  # this is a copy, not a view

    parsed_body = _parse_body(request, body)

    forwarded = None
    if request.forwarded_host:
        forwarded = [request.forwarded_host]

    content_length = None
    try:
        content_length = request.content_length
    except HTTPInvalidHeader:
        pass

    return InboundRequest(
        request_id=request_id,
        # timestamp,
        protocol=None,
        method=request.method,
        host=request.host,
        port=request.port,
        path=request.path,
        query=request.params,
        # fragment
        headers=request.headers,
        body=body,
        parsed_body=parsed_body,
        scheme=request.scheme,
        context=context,
        source_ip_address=request.access_route[0],
        auth_id=get_authentication_header_scheme(request.auth),
        user_agent=request.user_agent,
        content_length=content_length,
        content_type=request.content_type,
        # cookies
        forwarded=forwarded,
        forwarded_scheme=request.forwarded_scheme,
    )
