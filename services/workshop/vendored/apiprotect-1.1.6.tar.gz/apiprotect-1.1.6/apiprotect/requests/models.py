import time
from enum import Enum
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Union
from uuid import uuid4

from pydantic import BaseModel
from pydantic import Field
from requests.structures import CaseInsensitiveDict
from typing_extensions import Literal

HeaderSingleValueType = Union[str, bytes]  # AWS may use bytes for header values
HeadersType = Dict[str, Union[HeaderSingleValueType, List[HeaderSingleValueType]]]
QueryParamsType = Dict[str, Union[str, List[str]]]
CookiesType = Dict[str, Union[str, List[str]]]
HttpMethodType = Literal["CONNECT", "DELETE", "GET", "HEAD", "OPTIONS", "PATCH", "POST", "PUT", "TRACE"]


class RequestLocationEnum(str, Enum):
    HEADERS = "HEADERS"
    BODY = "BODY"
    QUERY_STRING = "QUERY"
    COOKIES = "COOKIES"
    PATH = "PATH"


class InboundRequest(BaseModel):
    """Inbound request from client

    The following fields should contain the values as seen from the originating
    client request and not internal values from proxied requests.

    For example:

    Given this series of requests from a client to the application server

    [client 1.2.3.4] -> https://abc.com/path1?key=val -> [proxy 10.1.1.1] -> http://appserver:9001/path-rewrite/key/val

    the InboundRequest's values should :

    inbound_request.host == "domain.com"
    inbound_request.port == 443
    inbound_request.path == "path1"
    inbound_request.scheme == "https"
    inbound_request.source_ip_address == "1.2.3.4"
    inbound_request.query == {"key":"val"}

    """

    # Should be taken from request if possible
    request_id: str = Field(default_factory=lambda: str(uuid4()))

    # Should be taken from request if possible
    timestamp: float = Field(default_factory=time.time)

    protocol: Optional[str] = None  # "HTTP/1.1"
    method: Optional[HttpMethodType] = None

    host: Optional[str] = None  # hostname or ip address used by client
    port: Optional[int] = None  # tcp port used by client
    path: Optional[str] = None  # path used by client w/o query or fragment

    # parsed query params as output by urllib.parse.parse_qs
    # with multi-values keys stored as a list of values
    query: Optional[QueryParamsType] = None

    fragment: Optional[str] = None

    # parsed headers with multi-values keys stored as a list of values
    headers: Optional[HeadersType] = None
    body: Optional[str] = None
    parsed_body: Optional[Any] = None

    # additional request context
    scheme: Optional[str] = None  # http, https, ws, wss

    # container for additional information not part of http request, eg,
    # the lambda request context
    context: Optional[Dict[str, Any]] = None

    # derived request properties
    source_ip_address: Optional[str] = None  # client ip, not proxy

    auth_id: Optional[str] = None

    user_agent: Optional[str] = None
    content_length: Optional[int] = None
    content_type: Optional[str] = None

    # parsed cookies with multi-values keys stored as a list of values
    cookies: Optional[CookiesType] = None

    # Should contain either X-Forwarded-For or Forwarded header values
    # Example:
    #  X-Forwarded-For: 192.0.2.43, "[2001:db8:cafe::17]"
    #  Forwarded: for=192.0.2.43, for="[2001:db8:cafe::17]"
    forwarded: Optional[List[str]] = None  # either 192.0.2.43, "[2001:db8:cafe::17]"

    # Should *convey* value of X-Forwarded-Proto value
    # Examples:
    #   Given `X-Forwarded-Proto: https`` then `forwarded_scheme`= "https"
    # Other non-standard forms:
    #   Microsoft
    #   Given `Front-End-Https: on` then `forwarded_scheme`= "https"
    #   Given `Front-End-Https: off` then `forwarded_scheme`= "http"
    #   Given `X-Forwarded-Ssl: on` then `forwarded_scheme`= "https"`
    forwarded_scheme: Optional[str] = None

    def get_case_insensitive_headers(self) -> CaseInsensitiveDict:
        return CaseInsensitiveDict(self.headers)


class InboundRequestResponse(BaseModel):
    request_id: str  # request_id for which this is a response
    timestamp: float = Field(default_factory=time.time)
    status_code: Optional[str]
    # parsed headers with multi-values keys stored as a list of values
    headers: Optional[HeadersType]

    def get_case_insensitive_headers(self) -> CaseInsensitiveDict:
        return CaseInsensitiveDict(self.headers)


class OutboundRequest(BaseModel):
    protocol: Optional[str] = None  # "HTTP/1.1"
    scheme: Optional[str] = None  # http, https, ws, wss
    host: Optional[str] = None  # 1.1.1.1 or subdomain.domain.com
    port: Optional[int] = None
    method: Optional[HttpMethodType] = None
    url: Optional[str] = None  # either url or path, may contain query
    body: Any
    # parsed headers with multi-values keys stored as a list of values
    headers: Optional[HeadersType] = None

    def get_case_insensitive_headers(self) -> CaseInsensitiveDict:
        return CaseInsensitiveDict(self.headers)
