from copy import deepcopy
from math import log
from typing import Any
from typing import Dict
from typing import Optional
from urllib.parse import parse_qs
from urllib.parse import urlencode
from urllib.parse import urlsplit
from urllib.parse import urlunsplit

LOWERCASE_HEADER_AUTH_KEYS = {"authorization", "proxy-authorization", "x-api-key", "cookie", "x-amz-security-token"}


# https://www.iana.org/assignments/http-authschemes/http-authschemes.txt

LOWERCASE_AUTHENTICATION_SCHEMES = {
    "basic",  #                       [RFC7617]
    "bearer",  #                      [RFC6750]
    "digest",  #                      [RFC7616]
    "hoba",  #                        [RFC7486, Section 3]
    "mutual",  #                      [RFC8120]
    "negotiate",  #                   [RFC4559, Section 3]
    "oauth",  #                       [RFC5849, Section 3.5.1]
    "scram-sha-1",  #                 [RFC7804]
    "scram-sha-256",  #               [RFC7804]
    "vapid",  #
    "aws4-hmac-sha256",
    "session",
}

PRINTABLE_SET = frozenset(
    "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~ "
)


def shannon_entropy(data: str) -> Optional[float]:
    """Calulcate Shannon entropy of a string."""
    if not isinstance(data, str):
        return None
    data_len = data.__len__()
    entropy = 0.0
    for x in PRINTABLE_SET.intersection(data):
        p_x = data.count(x) / data_len
        entropy += -p_x * log(p_x, 2)
    return entropy


def get_authentication_header_scheme(header_value: str) -> Optional[str]:
    try:
        _type = header_value.split()[0]
        if _type.lower() in LOWERCASE_AUTHENTICATION_SCHEMES:
            return _type
    except Exception:
        pass
    return None


def omit_dict_values(input_dict: Dict[str, Any]) -> Dict[str, Any]:
    if not input_dict:
        return input_dict
    safe_dict = {}
    for k, v in input_dict.items():
        if isinstance(v, str):
            if v.startswith("**omitted**"):
                safe_dict[k] = v
            else:
                try:
                    entropy = shannon_entropy(v)
                except Exception:
                    entropy = None
                safe_dict[k] = f"**omitted** type=str entropy={entropy}"
        else:
            safe_dict[k] = f"**omitted** type={type(v)}"
    return safe_dict


def omit_headers_auth(headers: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Return a deep copy of passed headers with Authorization value replaced with '**omitted**'.

    This function MUST NOT modify the headers it receives or it will break things.
    The modified headers should be used for logging only.
    """
    if not headers:
        return headers
    new_headers: Dict[str, Any] = {}
    for k, v in headers.items():
        if k.lower() in LOWERCASE_HEADER_AUTH_KEYS:
            new_headers[k] = "**omitted**"
        else:
            if isinstance(v, str):
                new_headers[k] = v
            else:
                # deepcopy to avoid risk of modifying multi-value dicts that may
                # contain lists or other mutable types
                new_headers[k] = deepcopy(v)
    return new_headers


def omit_query_params_auth(params: Dict[str, Any]) -> Dict[str, Any]:
    """Return dict with all values replaced with '**omitted**'.

    This function MUST NOT modify the dict it receives or it will break things.
    The modified url should be used for logging only.

    """
    if not params:
        return params

    return omit_dict_values(params)


def omit_query_string_auth(url: str) -> str:
    """Return url with all query values replaced with '**omitted**'.

    This function MUST NOT modify the url it receives or it will break things.
    The modified url should be used for logging only.

    """
    if not url:
        return url

    def noop_quote_plus(s: str, safe: str = "", encoding: Optional[str] = None, errors: Optional[str] = None) -> str:
        return s

    parsed_url = urlsplit(url)
    if not parsed_url.query:
        return url
    query_dict = {k: "**omitted**" for k, v in parse_qs(parsed_url.query).items()}
    query = urlencode(query_dict, doseq=True, quote_via=noop_quote_plus)  # type: ignore
    return urlunsplit((parsed_url.scheme, parsed_url.netloc, parsed_url.path, query, parsed_url.fragment))


def omit_cookies_auth(cookies: Dict[str, Any]) -> Dict[str, Any]:
    if not cookies:
        return cookies
    return omit_dict_values(cookies)
