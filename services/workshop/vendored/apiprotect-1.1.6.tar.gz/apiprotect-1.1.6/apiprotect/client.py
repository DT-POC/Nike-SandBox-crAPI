import logging
from typing import Optional

import requests
from requests import HTTPError

_logger = logging.getLogger(__name__)


class ApiProtectClient:
    @staticmethod
    def client_id_is_valid(client_id: Optional[str], url: str, timeout: Optional[float] = 10.0) -> bool:
        """Validate the client_id is authorized to access DataTheorem."""
        if not client_id:
            return False
        try:
            # TODO johng make better use of the requested config result if it succeeds
            response = requests.get(url, headers={"Authorization": f"Bearer {client_id}"}, timeout=timeout)
            response.raise_for_status()
        except HTTPError as e:
            if e.response.status_code == 403:
                _logger.warning(f"Unauthorized/invalid client_id: {client_id}")
                return False
            _logger.warning(f"Error while attempting to validate client_id: {e}. Assuming client_id is valid")
        except Exception as e:
            _logger.warning(f"Error while attempting to validate client_id: {e}. Assuming client_id is valid")
        return True
