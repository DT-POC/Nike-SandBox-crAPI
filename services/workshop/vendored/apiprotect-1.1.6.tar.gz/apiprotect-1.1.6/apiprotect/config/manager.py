import logging
import threading
from typing import List
from typing import Optional
from typing import TYPE_CHECKING
from typing import Union

from apiprotect.config.models import ApiProtectConfigurationV2
from apiprotect.config.sources import DefaultConfigSource
from apiprotect.config.sources import HttpSource

_logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from queue import SimpleQueue

ONE_HOUR = 60 * 60

SourceType = Union[HttpSource, DefaultConfigSource]


class ConfigManager:
    def __init__(
        self,
        client_id: str,
        config_url: str,
        config_http_timeout: float,
        sources: Optional[List[SourceType]] = None,
        max_config_age_secs: int = 60 * 60,
        debug: bool = False,
    ):
        self.max_config_age_secs = max_config_age_secs
        self.client_id = client_id
        self.config_url = config_url
        self.config_http_timeout = config_http_timeout
        self.debug = debug
        self._sources: List[SourceType] = sources or self.default_sources()

        self.current_config: Optional[ApiProtectConfigurationV2] = None

    def default_sources(self) -> List[SourceType]:
        _logger.debug("using default sources")
        sources: List[SourceType] = []
        if self.client_id and self.config_url:
            sources.append(HttpSource(self.config_url, self.config_http_timeout, self.client_id, debug=self.debug))
        sources.append(DefaultConfigSource())
        return sources

    def load(self) -> Optional[ApiProtectConfigurationV2]:
        for source in self._sources:
            try:
                config = source.load()
                if config:
                    self.current_config = config
                    _logger.debug(f"config loaded from {self.current_config.source}")
                    return self.current_config
            except Exception as e:
                _logger.error(f"Error loading config from {source}: {e}")
        return None

    def load_if_expired(self) -> Optional[ApiProtectConfigurationV2]:
        if not self.current_config or getattr(self.current_config, "expired", True):
            _logger.debug("config missing or expired")
            return self.load()
        return None

    @property
    def interval(self) -> int:
        try:
            return self.current_config.ttl  # type: ignore
        except Exception as e:
            _logger.warn(f"failed to read ttl from config: {e}")
            return self.max_config_age_secs


def run_forever(
    config_queue: "SimpleQueue",
    stop_event: threading.Event,
    client_id: str,
    config_url: str,
    config_http_timeout: float,
    debug: bool = False,
) -> None:
    _logger.debug("Starting")
    config_manager = ConfigManager(
        client_id=client_id, config_url=config_url, config_http_timeout=config_http_timeout, debug=debug
    )

    config_manager.load()
    config_queue.put(config_manager.current_config)

    while True:
        result = stop_event.wait(timeout=config_manager.interval)
        if result:
            _logger.info("Shutting down config manager thread")
            break
        new_config = config_manager.load_if_expired()
        if isinstance(new_config, ApiProtectConfigurationV2):
            config_queue.put(new_config)
        _logger.debug(f"will check config expiration in {config_manager.interval} seconds")
