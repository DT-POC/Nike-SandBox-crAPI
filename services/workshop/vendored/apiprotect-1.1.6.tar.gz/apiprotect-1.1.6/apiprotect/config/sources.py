import abc
import logging
from typing import Optional

import requests

from apiprotect.config.models import ApiProtectConfigurationV2

_logger = logging.getLogger(__name__)


class AbstractConfigSource(abc.ABC):
    @abc.abstractmethod
    def load(self) -> Optional[ApiProtectConfigurationV2]:
        raise NotImplementedError


class HttpSource(AbstractConfigSource):
    def __init__(
        self,
        url: str,
        timeout: float,
        client_id: Optional[str],
        debug: bool = False,
    ):
        self.client_id = client_id
        self.url = url
        self.timeout = timeout
        self.debug = debug
        self.session = requests.Session()
        if self.client_id:
            self.session.headers.update({"Authorization": f"Bearer {self.client_id}"})

    def load(self) -> Optional[ApiProtectConfigurationV2]:
        _logger.info("Loading config from %s for %s", self.url, self.client_id)
        try:
            resp = self.session.get(self.url, timeout=self.timeout)
            resp.raise_for_status()
            config = ApiProtectConfigurationV2.parse_obj(resp.json())
            config.metadata.source = self.url
            return config
        except requests.HTTPError as e:
            if e.response.status_code == 403:
                _logger.error(
                    "Bad/missing client_id, using default observability config. "
                    "Set `DT_API_PROTECT_CLIENT_ID` in environment or pass "
                    "`client_id` to API Protect middleware."
                )
            else:
                _logger.error(f"Failed to load config from {self.url}: {e}. Using default observability config.")
        except Exception as e:
            _logger.error(f"Failed to load config from {self.url}: {e}. Using default observability config.")
        return None


class DefaultConfigSource(AbstractConfigSource):
    def load(self) -> ApiProtectConfigurationV2:
        return ApiProtectConfigurationV2()
