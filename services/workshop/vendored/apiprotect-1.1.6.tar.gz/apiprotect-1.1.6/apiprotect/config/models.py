import time
from ipaddress import IPv4Network
from typing import FrozenSet
from typing import List
from typing import Optional

from pydantic import BaseModel
from pydantic import BaseSettings
from pydantic import Field

from apiprotect.version import __version__ as DT_API_PROTECT_VERSION

ONE_HOUR = 60 * 60


class SDKConfig(BaseSettings):
    """API Protect SDK configuration.

    Field Source Precedence:
    1. Arguments passed to the class initializer, eg, SDKConfig(reporting_url=...)
    2. Case-insensitive environment variables, eg `dT_aPi_PROtect_reporting_URL`
    3. The default field values for the model.

    """

    client_id: str = "unknown"

    config_url: str = "https://api-protect-api.securetheorem.com/client_sdk/v1/configurations/current"
    config_timeout: float = 3.0

    config_path: str = "/tmp/data_theorem_api_protect_config.json"

    report_url: str = "https://api-protect-api.securetheorem.com/client_sdk/v1/telemetry/agent_report"
    report_timeout: float = 3.0

    reverse_ip_lookup_url: str = ""
    reverse_ip_lookup_timeout: float = 3.0

    malicious_ip_lookup_url: str = ""
    malicious_ip_lookup_timeout: float = 3.0

    debug: bool = False
    version: str = DT_API_PROTECT_VERSION

    deactivate: bool = False

    class Config:
        env_prefix = "DT_API_PROTECT_"
        allow_mutation = False


class ApiProtectBaseModel(BaseModel):
    class Config:
        frozen = True


class AttackPreventionConfiguration(ApiProtectBaseModel):
    block_ssrf_attacks: bool = False
    ssrf_allowed_ip_ranges: FrozenSet[IPv4Network] = frozenset()  # list of cidrs, use /32 for single ip, eg, 1.1.1.1/32
    block_bot_attacks: bool = False
    block_owasp_top_ten_attacks: bool = False
    block_sqli_attacks: bool = False
    block_xss_attacks: bool = False


class EncryptionConfiguration(ApiProtectBaseModel):
    block_non_tls_outbound_requests: bool = False
    block_non_tls_inbound_requests: bool = False


class AuthenticationConfiguration(ApiProtectBaseModel):
    blocked_user_ids: FrozenSet[str] = frozenset()
    blocked_oauth_clients: FrozenSet[str] = frozenset()


class AuthorizationConfiguration(ApiProtectBaseModel):
    blocked_countries: FrozenSet[str] = frozenset()  # ISO 3166-1 alpha-2 country codes
    blocked_ip_address_ranges: FrozenSet[
        IPv4Network
    ] = frozenset()  # list of cidrs, use /32 for single ip, eg, 1.1.1.1/32
    blocked_domains: FrozenSet[str] = frozenset()
    blocked_user_agents: FrozenSet[str] = frozenset()


class VolumetricAbuseEndpointConfiguration(ApiProtectBaseModel):
    url: str
    rps: float
    window: float
    per_ip_address: bool = False


class VolumetricAbuseConfiguration(ApiProtectBaseModel):
    block_on_abuse: bool = False
    endpoints_configurations: List[VolumetricAbuseEndpointConfiguration] = []

    def get_config_for_url(self, url: str) -> Optional[VolumetricAbuseEndpointConfiguration]:
        for endpoint_configuration in self.endpoints_configurations:
            if endpoint_configuration.url == url:
                return endpoint_configuration
        return None


class ConfigMeta(BaseModel):
    """Metadata about protection configuration."""

    timestamp: float = Field(default_factory=time.time)  # the timestamp when the config was fetched
    source: str = "DEFAULT"  # path or url where config was loaded


class ApiProtectConfigurationV2(BaseModel):
    """API Protect protection configuration."""

    # service configuration
    metadata: ConfigMeta = Field(default_factory=ConfigMeta)
    version: int = 1  # incremented when customer updates configuration
    ttl: int = ONE_HOUR
    sdk_debug: bool = False
    schema_version: int = 2

    # fields customer configures
    name: str = "DEFAULT"
    attack_prevention_configuration: AttackPreventionConfiguration = AttackPreventionConfiguration()
    encryption_configuration: EncryptionConfiguration = EncryptionConfiguration()
    authentication_configuration: AuthenticationConfiguration = AuthenticationConfiguration()
    authorization_configuration: AuthorizationConfiguration = AuthorizationConfiguration()
    volumetric_abuse_configuration: VolumetricAbuseConfiguration = VolumetricAbuseConfiguration()

    def age(self) -> float:
        return time.time() - self.timestamp

    def expired(self) -> bool:
        try:
            return (time.time() - (self.timestamp + self.ttl)) > 0
        except Exception:
            return True

    @property
    def source(self) -> str:
        return self.metadata.source

    @property
    def timestamp(self) -> float:
        return self.metadata.timestamp
