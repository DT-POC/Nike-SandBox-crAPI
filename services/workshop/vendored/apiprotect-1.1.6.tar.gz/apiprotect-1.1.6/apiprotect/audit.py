import logging
from dataclasses import dataclass
from typing import Union

from apiprotect.checks import Result
from apiprotect.checks import should_block_inbound_request
from apiprotect.checks import should_block_outbound_request
from apiprotect.config.models import ApiProtectConfigurationV2
from apiprotect.events import InboundHttpRequestEvent
from apiprotect.events import OutboundHttpRequestEvent
from apiprotect.events.alert import AlertEvent
from apiprotect.exceptions import PolicyViolationError

_logger = logging.getLogger(__name__)


@dataclass
class AuditResult:
    event: Union[OutboundHttpRequestEvent, InboundHttpRequestEvent, AlertEvent]
    config: ApiProtectConfigurationV2
    result: Result
    is_complete: bool = False

    @property
    def request_id(self) -> str:
        return self.event.request_id

    @property
    def is_allow(self) -> bool:
        return self.result.should_block is False

    @property
    def is_block(self) -> bool:
        return self.result.should_block

    def raise_if_block(self) -> None:
        # take care to send event to report manager before raising
        if not self.is_block:
            return
        raise PolicyViolationError(audit_result=self)


def audit_event(
    event: Union[OutboundHttpRequestEvent, InboundHttpRequestEvent], config: ApiProtectConfigurationV2
) -> AuditResult:
    if isinstance(event, OutboundHttpRequestEvent):
        outbound_request = event.record
        result = should_block_outbound_request(outbound_request, config)
        _logger.debug(f"API Protect audit result: {result}")
        return AuditResult(event=event, config=config, result=result)
    elif isinstance(event, InboundHttpRequestEvent):
        inbound_request = event.record
        result = should_block_inbound_request(inbound_request, config)
        _logger.debug(f"API Protect audit result: {result}")
        return AuditResult(event=event, config=config, result=result)
    else:
        raise ValueError(f"Event {event} is not auditable")
