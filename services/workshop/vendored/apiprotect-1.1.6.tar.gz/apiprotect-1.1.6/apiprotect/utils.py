import datetime
from collections.abc import Mapping
from collections.abc import Sequence
from collections.abc import Set
from contextlib import ContextDecorator
from typing import TYPE_CHECKING
from typing import Any
from typing import Generator
from typing import Optional
from typing import Set as SetType
from typing import Tuple
from typing import Union

if TYPE_CHECKING:
    from logging import Logger  # nosemgrep: no_import_logging
    from typing import Mapping as MappingType


def _utcnow() -> datetime.datetime:
    return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)


class log_and_suppress(ContextDecorator):
    """Context manager/decorator to log and suppress specified exceptions

    After the exception is suppressed, execution proceeds with the next
    statement following the with statement:

         with log_and_suppress(FileNotFoundError):
             os.remove(somefile)
         # Execution still resumes here if the file was already removed

    May be used as decorator too:

        @log_and_supress(FileNotFoundError, logger=_logger):
        def remove(somefile):
            os.remove(somefile)

    """

    def __init__(
        self, *exceptions: Union[type, Tuple[type]], logger: Optional["Logger"] = None, level: str = "info"
    ) -> None:
        self._exceptions = exceptions
        self.level = level
        default_log_func = getattr(logger, "info", None)
        self.log_func = getattr(logger, level.lower(), None) or default_log_func

    def __enter__(self) -> Any:
        return self

    def __exit__(self, exctype: Any, excinst: Any, exctb: Any) -> bool:
        if exctype is not None:
            if self.log_func:
                if self.level == "exception":
                    self.log_func("Exception", exc_info=(exctype, excinst, exctb))
                else:
                    self.log_func(f"Handled {exctype}: {excinst} ")

        # returning fale swallows the exception, returning true raises the it
        return exctype is not None and issubclass(exctype, self._exceptions)


def objwalk(
    obj: Any, path: Tuple = (), to_visit: Optional[SetType[int]] = None
) -> Generator[Tuple[Any, Tuple, Any], None, None]:
    """Depth-first object traversal."""
    if to_visit is None:
        to_visit = set()
    iterator = None
    if isinstance(obj, Mapping):
        iterator = lambda mapping: mapping.items()  # noqa: E731
    elif isinstance(obj, (Set, Sequence)) and not isinstance(obj, (str, bytes)):
        iterator = enumerate
    if iterator:
        if id(obj) not in to_visit:
            to_visit.add(id(obj))
            for path_item, value in iterator(obj):
                for result in objwalk(value, path + (path_item,), to_visit):
                    yield result
            to_visit.remove(id(obj))
    else:
        yield type(obj), path, obj


def case_insensitive_mapping_lookup(
    mapping: "MappingType[str, Any]", key: str, default: Optional[Any] = None
) -> Optional[Any]:
    """Get mapping value by case insensitive key.

    Due to collisions for keys with different cases, may return a list of values.

    >>> mapping = {"Aa":1, "aA":2, "B": 3}
    >>> case_insensitive_mapping_lookup(mapping, "Aa")
    [1,2]
    >>> case_insensitive_mapping_lookup(mapping, "aA")
    [1,2]
    >>> case_insensitive_mapping_lookup(mapping, "aa")
    [1,2]
    >>> case_insensitive_mapping_lookup(mapping, "AA")
    [1,2]
    >>> case_insensitive_mapping_lookup(mapping, "b")
    3
    >>> case_insensitive_mapping_lookup(mapping, "B")
    3
    >>> case_insensitive_mapping_lookup(mapping, "c")
    None
    >>> case_insensitive_mapping_lookup(mapping, "c", 4)
    4
    """
    key_lower = key.lower()
    matches = [v for k, v in mapping.items() if k.lower() == key_lower]
    if len(matches) == 1:
        return matches[0]
    elif not matches:
        return default
    else:
        return matches
